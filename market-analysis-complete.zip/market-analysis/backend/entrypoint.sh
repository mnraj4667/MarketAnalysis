#!/bin/sh
# Entrypoint: wait for Postgres then start the API

echo "⏳ Waiting for PostgreSQL..."
until pg_isready -h "${PGHOST:-postgres}" -U "${PGUSER:-market_user}" -q; do
  sleep 1
done
echo "✅ PostgreSQL ready"

echo "⏳ Waiting for Redis..."
until redis-cli -h "${REDIS_HOST:-redis}" ping 2>/dev/null | grep -q PONG; do
  sleep 1
done
echo "✅ Redis ready"

echo "▶  Starting Market Analysis API..."
exec "$@"
