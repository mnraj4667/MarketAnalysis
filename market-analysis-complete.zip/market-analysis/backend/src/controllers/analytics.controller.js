const axios   = require('axios');
const { query } = require('../config/database');
const redis   = require('../config/redis');
const logger  = require('../utils/logger');

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

// ── helpers ───────────────────────────────────────────────────
function successJob(res, data) {
  res.json({ success: true, data });
}
function errRes(res, err, code = 500) {
  logger.error('Analytics error:', err);
  res.status(code).json({ success: false, error: err.message || String(err) });
}

// POST /api/analytics/sentiment
async function runSentiment(req, res) {
  try {
    const { campaign_id, source_type } = req.body;
    if (!campaign_id) return res.status(400).json({ success: false, error: 'campaign_id required' });

    // Pull text records from DB
    let records = [];
    if (!source_type || source_type === 'classified_ad') {
      const { rows } = await query(
        'SELECT ad_id AS id, ad_text AS text FROM classified_ads WHERE campaign_id=$1 AND ad_text IS NOT NULL LIMIT 500',
        [campaign_id]
      );
      records.push(...rows.map(r => ({ ...r, source_type: 'classified_ad' })));
    }
    if (!source_type || source_type === 'social_post') {
      const { rows } = await query(
        `SELECT smm.metric_id AS id, $1::text AS text FROM social_media_metrics smm
         WHERE smm.campaign_id=$2 LIMIT 200`,
        ['Social media post content', campaign_id]
      );
      records.push(...rows.map(r => ({ ...r, source_type: 'social_post' })));
    }

    // Call Python AI service
    const aiRes = await axios.post(`${AI_URL}/sentiment`, { texts: records.map(r => r.text) });
    const results = aiRes.data.results;

    // Persist results
    let saved = 0;
    for (let i = 0; i < records.length && i < results.length; i++) {
      const r = results[i];
      await query(
        `INSERT INTO sentiment_results
         (source_id, source_type, campaign_id, sentiment_class, confidence, positive_score, negative_score, neutral_score)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [records[i].id, records[i].source_type, campaign_id,
         r.label, r.confidence, r.positive, r.negative, r.neutral]
      );
      saved++;
    }

    // Build summary
    const summary = results.reduce((acc, r) => {
      acc[r.label] = (acc[r.label] || 0) + 1;
      return acc;
    }, {});

    await redis.set(`sentiment:${campaign_id}`, { summary, total: saved }, 3600);
    successJob(res, { campaign_id, total: saved, summary, results: results.slice(0, 50) });
  } catch (err) {
    errRes(res, err);
  }
}

// GET /api/analytics/sentiment/:campaignId
async function getSentiment(req, res) {
  try {
    const { campaignId } = req.params;
    const cached = await redis.get(`sentiment:${campaignId}`);
    if (cached) return successJob(res, { ...cached, fromCache: true });

    const { rows } = await query(
      `SELECT sentiment_class, COUNT(*) AS count,
              AVG(confidence) AS avg_confidence,
              AVG(positive_score) AS avg_positive,
              AVG(negative_score) AS avg_negative,
              AVG(neutral_score) AS avg_neutral
       FROM sentiment_results WHERE campaign_id=$1 GROUP BY sentiment_class`,
      [campaignId]
    );
    const summary = {};
    rows.forEach(r => { summary[r.sentiment_class] = parseInt(r.count); });
    successJob(res, { campaign_id: campaignId, summary, details: rows });
  } catch (err) {
    errRes(res, err);
  }
}

// POST /api/analytics/engagement
async function runEngagement(req, res) {
  try {
    const { campaign_id } = req.body;
    if (!campaign_id) return res.status(400).json({ success: false, error: 'campaign_id required' });

    const { rows } = await query(
      `SELECT platform, AVG(engagement_rate) AS avg_rate,
              SUM(impressions) AS total_impressions, SUM(clicks) AS total_clicks,
              SUM(likes) AS total_likes, SUM(comments) AS total_comments,
              SUM(shares) AS total_shares
       FROM social_media_metrics WHERE campaign_id=$1 GROUP BY platform`,
      [campaign_id]
    );

    const aiRes = await axios.post(`${AI_URL}/engagement`, { metrics: rows });
    const analysis = aiRes.data;

    await query(
      `INSERT INTO engagement_results (campaign_id, channel, engagement_rate, top_factors, recommendations)
       VALUES ($1,$2,$3,$4,$5)`,
      [campaign_id, 'social_media', analysis.avg_engagement || 0,
       JSON.stringify(analysis.top_factors || []),
       JSON.stringify(analysis.recommendations || [])]
    );

    successJob(res, { campaign_id, platform_breakdown: rows, analysis });
  } catch (err) {
    errRes(res, err);
  }
}

// POST /api/analytics/forecast
async function runForecast(req, res) {
  try {
    const { campaign_id, metric = 'engagement_rate', horizon_days = 30 } = req.body;
    if (!campaign_id) return res.status(400).json({ success: false, error: 'campaign_id required' });

    const { rows } = await query(
      `SELECT metric_date::text AS date, ${metric}::float AS value
       FROM social_media_metrics WHERE campaign_id=$1 AND ${metric} IS NOT NULL
       ORDER BY metric_date`,
      [campaign_id]
    );

    if (rows.length < 7) {
      // Generate synthetic data for demo
      const synthetic = Array.from({ length: 30 }, (_, i) => ({
        date: new Date(Date.now() - (29 - i) * 86400000).toISOString().split('T')[0],
        value: 3 + Math.sin(i * 0.4) + Math.random() * 0.5
      }));
      rows.push(...synthetic);
    }

    const aiRes = await axios.post(`${AI_URL}/forecast`, {
      series: rows,
      horizon_days,
      metric
    });
    const forecastData = aiRes.data;

    const { rows: saved } = await query(
      `INSERT INTO forecast_results (campaign_id, metric_name, horizon_days, forecast_values, confidence_upper, confidence_lower, mape)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING result_id`,
      [campaign_id, metric, horizon_days,
       JSON.stringify(forecastData.forecast || []),
       JSON.stringify(forecastData.upper || []),
       JSON.stringify(forecastData.lower || []),
       forecastData.mape || 0]
    );

    successJob(res, {
      result_id: saved[0].result_id,
      campaign_id,
      metric,
      horizon_days,
      historical: rows,
      forecast: forecastData
    });
  } catch (err) {
    errRes(res, err);
  }
}

// POST /api/analytics/segment
async function runSegmentation(req, res) {
  try {
    const { campaign_id, n_clusters = 6 } = req.body;
    if (!campaign_id) return res.status(400).json({ success: false, error: 'campaign_id required' });

    const { rows: metrics } = await query(
      `SELECT platform, AVG(engagement_rate) AS engagement,
              AVG(CASE WHEN impressions > 0 THEN clicks::float/impressions ELSE 0 END) AS ctr,
              SUM(conversions) AS conversions, SUM(spend) AS spend
       FROM social_media_metrics WHERE campaign_id=$1 GROUP BY platform`,
      [campaign_id]
    );

    const aiRes = await axios.post(`${AI_URL}/segment`, {
      campaign_id,
      metrics,
      n_clusters
    });
    const segments = aiRes.data.segments;

    // Clear old segments
    await query('DELETE FROM customer_segments WHERE campaign_id=$1', [campaign_id]);

    for (const seg of segments) {
      await query(
        `INSERT INTO customer_segments (campaign_id, segment_name, segment_label, characteristics, member_count, percentage)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [campaign_id, seg.name, seg.label, JSON.stringify(seg.characteristics), seg.count, seg.percentage]
      );
    }

    successJob(res, { campaign_id, segments, total_clusters: segments.length });
  } catch (err) {
    errRes(res, err);
  }
}

// GET /api/analytics/segments/:campaignId
async function getSegments(req, res) {
  try {
    const { rows } = await query(
      'SELECT * FROM customer_segments WHERE campaign_id=$1 ORDER BY percentage DESC',
      [req.params.campaignId]
    );
    successJob(res, rows);
  } catch (err) {
    errRes(res, err);
  }
}

// GET /api/analytics/performance/:campaignId
async function getPerformance(req, res) {
  try {
    const id = req.params.campaignId;
    const [camp, social, events, sentiment] = await Promise.all([
      query('SELECT * FROM campaigns WHERE campaign_id=$1', [id]),
      query(
        `SELECT SUM(impressions) AS impressions, SUM(reach) AS reach, SUM(clicks) AS clicks,
                SUM(conversions) AS conversions, SUM(spend) AS spend,
                AVG(engagement_rate) AS avg_engagement
         FROM social_media_metrics WHERE campaign_id=$1`, [id]
      ),
      query(
        `SELECT SUM(actual_reach) AS reach, SUM(conversions) AS conversions,
                SUM(revenue) AS revenue, AVG(satisfaction_score) AS satisfaction
         FROM promotional_events WHERE campaign_id=$1`, [id]
      ),
      query(
        `SELECT sentiment_class, COUNT(*) AS count FROM sentiment_results
         WHERE campaign_id=$1 GROUP BY sentiment_class`, [id]
      )
    ]);

    if (!camp.rows.length) return res.status(404).json({ success: false, error: 'Campaign not found' });

    const socialM = social.rows[0];
    const eventM  = events.rows[0];
    const sentMap = {};
    sentiment.rows.forEach(r => { sentMap[r.sentiment_class] = parseInt(r.count); });

    const spend = parseFloat(socialM.spend) || 1;
    const conv  = parseInt(socialM.conversions) + parseInt(eventM.conversions || 0);
    const roi   = eventM.revenue ? (parseFloat(eventM.revenue) / spend) : null;

    successJob(res, {
      campaign: camp.rows[0],
      social_metrics: socialM,
      event_metrics: eventM,
      sentiment: sentMap,
      kpis: {
        total_reach:       (parseInt(socialM.reach) || 0) + (parseInt(eventM.reach) || 0),
        total_conversions: conv,
        avg_engagement:    parseFloat(socialM.avg_engagement) || 0,
        roi,
        sentiment_score:   sentMap.positive ? Math.round(sentMap.positive / Object.values(sentMap).reduce((a,b)=>a+b,1) * 100) : null
      }
    });
  } catch (err) {
    errRes(res, err);
  }
}

module.exports = { runSentiment, getSentiment, runEngagement, runForecast, runSegmentation, getSegments, getPerformance };
