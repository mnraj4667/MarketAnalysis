const { query } = require('../config/database');
const logger    = require('../utils/logger');

// GET /api/campaigns
async function list(req, res) {
  try {
    const { status, channel, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const conditions = [];
    const params = [];
    let idx = 1;

    if (status) { conditions.push(`c.status = $${idx++}`); params.push(status); }
    if (channel) { conditions.push(`c.channel = $${idx++}`); params.push(channel); }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await query(
      `SELECT c.*, u.full_name AS created_by_name,
              (SELECT COUNT(*) FROM classified_ads WHERE campaign_id = c.campaign_id) AS classified_count,
              (SELECT COUNT(*) FROM promotional_events WHERE campaign_id = c.campaign_id) AS event_count,
              (SELECT COUNT(*) FROM social_media_metrics WHERE campaign_id = c.campaign_id) AS social_days
       FROM campaigns c LEFT JOIN users u ON c.created_by = u.user_id
       ${where} ORDER BY c.created_at DESC LIMIT $${idx++} OFFSET $${idx++}`,
      [...params, limit, offset]
    );
    const { rows: cnt } = await query(`SELECT COUNT(*) FROM campaigns c ${where}`, params);
    res.json({ success: true, data: rows, meta: { total: parseInt(cnt[0].count), page: +page, limit: +limit } });
  } catch (err) {
    logger.error('Campaign list error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/campaigns/:id
async function getOne(req, res) {
  try {
    const { rows } = await query(
      `SELECT c.*, u.full_name AS created_by_name FROM campaigns c
       LEFT JOIN users u ON c.created_by = u.user_id WHERE c.campaign_id = $1`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, error: 'Campaign not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

// POST /api/campaigns
async function create(req, res) {
  try {
    const { name, description, campaign_type, channel, start_date, end_date, budget, target_segment } = req.body;
    if (!name) return res.status(400).json({ success: false, error: 'Campaign name is required' });

    const { rows } = await query(
      `INSERT INTO campaigns (name, description, campaign_type, channel, start_date, end_date, budget, target_segment, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [name, description, campaign_type, channel, start_date, end_date, budget, target_segment, req.user.user_id]
    );
    res.status(201).json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

// PUT /api/campaigns/:id
async function update(req, res) {
  try {
    const { name, description, campaign_type, channel, start_date, end_date, budget, status, target_segment } = req.body;
    const { rows } = await query(
      `UPDATE campaigns SET name=$1, description=$2, campaign_type=$3, channel=$4,
       start_date=$5, end_date=$6, budget=$7, status=$8, target_segment=$9, updated_at=NOW()
       WHERE campaign_id=$10 RETURNING *`,
      [name, description, campaign_type, channel, start_date, end_date, budget, status, target_segment, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, error: 'Campaign not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

// DELETE /api/campaigns/:id
async function remove(req, res) {
  try {
    const { rows } = await query('DELETE FROM campaigns WHERE campaign_id=$1 RETURNING campaign_id', [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, error: 'Campaign not found' });
    res.json({ success: true, message: 'Campaign deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { list, getOne, create, update, remove };
