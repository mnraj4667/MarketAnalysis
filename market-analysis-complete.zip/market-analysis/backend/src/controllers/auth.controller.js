const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const { query } = require('../config/database');
const redis  = require('../config/redis');
const logger = require('../utils/logger');

const JWT_SECRET         = process.env.JWT_SECRET         || 'dev_secret';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dev_refresh_secret';
const ACCESS_TTL  = '15m';
const REFRESH_TTL = '7d';
const REFRESH_TTL_SEC = 7 * 24 * 3600;

function generateTokens(userId, email, role) {
  const payload = { userId, email, role };
  const accessToken  = jwt.sign(payload, JWT_SECRET,         { expiresIn: ACCESS_TTL });
  const refreshToken = jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: REFRESH_TTL });
  return { accessToken, refreshToken };
}

// POST /api/auth/login
async function login(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ success: false, error: 'Email and password required' });

    const { rows } = await query(
      `SELECT u.*, r.role_name, r.permissions
       FROM users u JOIN roles r ON u.role_id = r.role_id
       WHERE u.email = $1`, [email.toLowerCase()]
    );
    if (!rows.length)
      return res.status(401).json({ success: false, error: 'Invalid credentials' });

    const user = rows[0];
    if (!user.is_active)
      return res.status(401).json({ success: false, error: 'Account is disabled' });

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid)
      return res.status(401).json({ success: false, error: 'Invalid credentials' });

    const { accessToken, refreshToken } = generateTokens(user.user_id, user.email, user.role_name);

    // Store refresh token in Redis
    await redis.set(`refresh:${user.user_id}`, refreshToken, REFRESH_TTL_SEC);

    // Update last login
    await query('UPDATE users SET last_login = NOW() WHERE user_id = $1', [user.user_id]);

    logger.info(`User logged in: ${email}`);
    res.json({
      success: true,
      data: {
        accessToken,
        refreshToken,
        user: {
          id:       user.user_id,
          email:    user.email,
          fullName: user.full_name,
          role:     user.role_name,
          permissions: user.permissions
        }
      }
    });
  } catch (err) {
    logger.error('Login error:', err);
    res.status(500).json({ success: false, error: 'Login failed' });
  }
}

// POST /api/auth/register
async function register(req, res) {
  try {
    const { email, password, fullName, role = 'viewer' } = req.body;
    if (!email || !password || !fullName)
      return res.status(400).json({ success: false, error: 'Email, password and full name required' });

    const existing = await query('SELECT user_id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing.rows.length)
      return res.status(409).json({ success: false, error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 12);
    const { rows: roleRows } = await query('SELECT role_id FROM roles WHERE role_name = $1', [role]);
    if (!roleRows.length)
      return res.status(400).json({ success: false, error: 'Invalid role' });

    const { rows } = await query(
      `INSERT INTO users (email, password_hash, full_name, role_id)
       VALUES ($1, $2, $3, $4) RETURNING user_id, email, full_name`,
      [email.toLowerCase(), hash, fullName, roleRows[0].role_id]
    );
    res.status(201).json({ success: true, data: rows[0] });
  } catch (err) {
    logger.error('Register error:', err);
    res.status(500).json({ success: false, error: 'Registration failed' });
  }
}

// POST /api/auth/refresh
async function refresh(req, res) {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken)
      return res.status(400).json({ success: false, error: 'Refresh token required' });

    const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET);
    const stored  = await redis.get(`refresh:${decoded.userId}`);
    if (stored !== refreshToken)
      return res.status(401).json({ success: false, error: 'Invalid refresh token' });

    const { accessToken, refreshToken: newRefresh } = generateTokens(decoded.userId, decoded.email, decoded.role);
    await redis.set(`refresh:${decoded.userId}`, newRefresh, REFRESH_TTL_SEC);

    res.json({ success: true, data: { accessToken, refreshToken: newRefresh } });
  } catch (err) {
    res.status(401).json({ success: false, error: 'Invalid or expired refresh token' });
  }
}

// POST /api/auth/logout
async function logout(req, res) {
  try {
    // Blacklist the access token until its natural expiry
    const token = req.token;
    const decoded = jwt.decode(token);
    const ttl = decoded ? decoded.exp - Math.floor(Date.now() / 1000) : 900;
    if (ttl > 0) await redis.set(`blacklist:${token}`, '1', ttl);

    // Remove refresh token
    if (req.user) await redis.del(`refresh:${req.user.user_id}`);

    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Logout failed' });
  }
}

// GET /api/auth/me
async function me(req, res) {
  res.json({
    success: true,
    data: {
      id:       req.user.user_id,
      email:    req.user.email,
      fullName: req.user.full_name,
      role:     req.user.role_name,
      permissions: req.user.permissions
    }
  });
}

module.exports = { login, register, refresh, logout, me };
