const multer  = require('multer');
const path    = require('path');
const XLSX    = require('xlsx');
const { parse } = require('csv-parse/sync');
const fs      = require('fs');
const { query }  = require('../config/database');
const SocialPost = require('../models/SocialPost.model');
const logger     = require('../utils/logger');

// ── Multer config ─────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['.csv', '.xlsx', '.xls', '.xml'];
    if (allowed.includes(path.extname(file.originalname).toLowerCase())) cb(null, true);
    else cb(new Error('Only CSV, Excel and XML files are allowed'));
  }
});

// POST /api/data/classifieds/upload
async function uploadClassifieds(req, res) {
  try {
    if (!req.file) return res.status(400).json({ success: false, error: 'No file uploaded' });
    const { campaign_id } = req.body;
    const ext = path.extname(req.file.originalname).toLowerCase();

    let records = [];
    if (ext === '.csv') {
      const content = fs.readFileSync(req.file.path, 'utf8');
      records = parse(content, { columns: true, skip_empty_lines: true, trim: true });
    } else if (ext === '.xlsx' || ext === '.xls') {
      const wb   = XLSX.readFile(req.file.path);
      const ws   = wb.Sheets[wb.SheetNames[0]];
      records = XLSX.utils.sheet_to_json(ws);
    }

    let imported = 0, failed = 0;
    const errors = [];

    for (const rec of records) {
      try {
        await query(
          `INSERT INTO classified_ads
           (campaign_id, publication, category, ad_text, contact_info, pricing_tier, location, pub_date, impressions, responses, cost)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
          [
            campaign_id || null,
            rec.publication || rec.Publication || '',
            rec.category    || rec.Category    || '',
            rec.ad_text     || rec.AdText      || rec.text || '',
            rec.contact_info|| rec.Contact     || '',
            rec.pricing_tier|| rec.PricingTier || '',
            rec.location    || rec.Location    || '',
            rec.pub_date    || rec.PublicationDate || null,
            parseInt(rec.impressions || rec.Impressions || 0) || 0,
            parseInt(rec.responses   || rec.Responses   || 0) || 0,
            parseFloat(rec.cost      || rec.Cost        || 0) || 0
          ]
        );
        imported++;
      } catch (e) {
        failed++;
        errors.push({ row: imported + failed, error: e.message });
      }
    }

    fs.unlinkSync(req.file.path);
    res.json({ success: true, data: { imported, failed, total: records.length, errors: errors.slice(0,10) } });
  } catch (err) {
    logger.error('Upload classifieds error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// POST /api/data/social/import   (simulated – takes JSON payload or sample data)
async function importSocialMedia(req, res) {
  try {
    const { campaign_id, platform, posts = [], metrics = [] } = req.body;

    let savedPosts = 0;
    for (const p of posts) {
      await new SocialPost({
        campaign_id,
        platform,
        post_id:        p.post_id || `sim_${Date.now()}`,
        post_text:      p.text || p.post_text || '',
        post_date:      p.date || p.post_date || new Date(),
        impressions:    p.impressions || 0,
        reach:          p.reach || 0,
        likes:          p.likes || 0,
        comments:       p.comments || 0,
        shares:         p.shares || 0,
        engagement_rate: p.engagement_rate || 0,
        media_type:     p.media_type || 'text'
      }).save();
      savedPosts++;
    }

    let savedMetrics = 0;
    for (const m of metrics) {
      await query(
        `INSERT INTO social_media_metrics
         (campaign_id, platform, metric_date, impressions, reach, clicks, likes, comments, shares, saves, engagement_rate, spend, conversions)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
         ON CONFLICT (campaign_id, platform, metric_date) DO UPDATE SET
           impressions=EXCLUDED.impressions, reach=EXCLUDED.reach, engagement_rate=EXCLUDED.engagement_rate`,
        [
          campaign_id, platform,
          m.date || new Date().toISOString().split('T')[0],
          m.impressions || 0, m.reach || 0, m.clicks || 0,
          m.likes || 0, m.comments || 0, m.shares || 0, m.saves || 0,
          m.engagement_rate || 0, m.spend || 0, m.conversions || 0
        ]
      );
      savedMetrics++;
    }

    res.json({ success: true, data: { savedPosts, savedMetrics } });
  } catch (err) {
    logger.error('Social import error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// POST /api/data/events
async function createEvent(req, res) {
  try {
    const {
      campaign_id, event_name, event_type, start_date, end_date,
      location, target_segment, channels_used, budget,
      actual_reach, estimated_reach, response_rate, leads_generated,
      conversions, revenue, satisfaction_score, nps_score, notes
    } = req.body;

    if (!event_name) return res.status(400).json({ success: false, error: 'Event name is required' });

    const { rows } = await query(
      `INSERT INTO promotional_events
       (campaign_id, event_name, event_type, start_date, end_date, location, target_segment,
        channels_used, budget, actual_reach, estimated_reach, response_rate, leads_generated,
        conversions, revenue, satisfaction_score, nps_score, notes, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
       RETURNING *`,
      [
        campaign_id, event_name, event_type, start_date, end_date,
        location, target_segment,
        JSON.stringify(channels_used || []),
        budget, actual_reach, estimated_reach, response_rate, leads_generated,
        conversions, revenue, satisfaction_score, nps_score, notes, req.user.user_id
      ]
    );
    res.status(201).json({ success: true, data: rows[0] });
  } catch (err) {
    logger.error('Create event error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/data/events
async function listEvents(req, res) {
  try {
    const { campaign_id, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const conditions = campaign_id ? [`campaign_id = '${campaign_id}'`] : [];
    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await query(
      `SELECT * FROM promotional_events ${where} ORDER BY start_date DESC LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/data/classifieds
async function listClassifieds(req, res) {
  try {
    const { campaign_id, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    const params = campaign_id ? [campaign_id, limit, offset] : [limit, offset];
    const where  = campaign_id ? 'WHERE campaign_id = $1' : '';
    const p1 = campaign_id ? '$2' : '$1';
    const p2 = campaign_id ? '$3' : '$2';
    const { rows } = await query(
      `SELECT * FROM classified_ads ${where} ORDER BY pub_date DESC LIMIT ${p1} OFFSET ${p2}`,
      params
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/data/social/metrics
async function getSocialMetrics(req, res) {
  try {
    const { campaign_id, platform, from, to } = req.query;
    const conditions = [];
    const params = [];
    let idx = 1;
    if (campaign_id) { conditions.push(`campaign_id = $${idx++}`); params.push(campaign_id); }
    if (platform)    { conditions.push(`platform = $${idx++}`);    params.push(platform); }
    if (from)        { conditions.push(`metric_date >= $${idx++}`); params.push(from); }
    if (to)          { conditions.push(`metric_date <= $${idx++}`); params.push(to); }
    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const { rows } = await query(
      `SELECT * FROM social_media_metrics ${where} ORDER BY metric_date DESC LIMIT 200`,
      params
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = {
  uploadClassifieds,
  importSocialMedia,
  createEvent,
  listEvents,
  listClassifieds,
  getSocialMetrics,
  upload
};
