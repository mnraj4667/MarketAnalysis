const bcrypt = require('bcryptjs');
const { query } = require('../config/database');

async function list(req, res) {
  try {
    const { rows } = await query(
      `SELECT u.user_id, u.email, u.full_name, u.is_active, u.last_login, u.created_at,
              r.role_name FROM users u JOIN roles r ON u.role_id = r.role_id ORDER BY u.created_at DESC`
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

async function getOne(req, res) {
  try {
    const { rows } = await query(
      `SELECT u.user_id, u.email, u.full_name, u.is_active, u.last_login, r.role_name, r.permissions
       FROM users u JOIN roles r ON u.role_id = r.role_id WHERE u.user_id = $1`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, error: 'User not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

async function update(req, res) {
  try {
    const { full_name, is_active, role } = req.body;
    let roleId = null;
    if (role) {
      const { rows } = await query('SELECT role_id FROM roles WHERE role_name=$1', [role]);
      if (!rows.length) return res.status(400).json({ success: false, error: 'Invalid role' });
      roleId = rows[0].role_id;
    }
    const { rows } = await query(
      `UPDATE users SET
         full_name = COALESCE($1, full_name),
         is_active = COALESCE($2, is_active),
         role_id   = COALESCE($3, role_id),
         updated_at = NOW()
       WHERE user_id = $4 RETURNING user_id, email, full_name, is_active`,
      [full_name, is_active, roleId, req.params.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, error: 'User not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

async function changePassword(req, res) {
  try {
    const { current_password, new_password } = req.body;
    if (!current_password || !new_password)
      return res.status(400).json({ success: false, error: 'Both passwords required' });

    const { rows } = await query('SELECT password_hash FROM users WHERE user_id=$1', [req.user.user_id]);
    const valid = await bcrypt.compare(current_password, rows[0].password_hash);
    if (!valid) return res.status(400).json({ success: false, error: 'Current password incorrect' });

    const hash = await bcrypt.hash(new_password, 12);
    await query('UPDATE users SET password_hash=$1, updated_at=NOW() WHERE user_id=$2', [hash, req.user.user_id]);
    res.json({ success: true, message: 'Password updated' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

async function remove(req, res) {
  try {
    await query('UPDATE users SET is_active=false WHERE user_id=$1', [req.params.id]);
    res.json({ success: true, message: 'User deactivated' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { list, getOne, update, changePassword, remove };
