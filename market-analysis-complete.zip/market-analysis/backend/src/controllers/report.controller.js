const { query } = require('../config/database');
const logger    = require('../utils/logger');

async function generate(req, res) {
  try {
    const { title, report_type, campaign_id, format = 'json', parameters } = req.body;
    if (!title) return res.status(400).json({ success: false, error: 'Title required' });

    const { rows } = await query(
      `INSERT INTO reports (title, report_type, campaign_id, created_by, format, parameters, status)
       VALUES ($1,$2,$3,$4,$5,$6,'completed') RETURNING *`,
      [title, report_type, campaign_id, req.user.user_id, format, JSON.stringify(parameters || {})]
    );

    // Build report data inline (for JSON format)
    let reportData = { title, generated_at: new Date().toISOString(), campaign_id };

    if (campaign_id) {
      const [camp, social, events, sentiment, segments] = await Promise.all([
        query('SELECT * FROM campaigns WHERE campaign_id=$1', [campaign_id]),
        query(`SELECT platform, SUM(impressions) AS impressions, SUM(reach) AS reach,
                      SUM(conversions) AS conversions, SUM(spend) AS spend,
                      AVG(engagement_rate) AS engagement_rate
               FROM social_media_metrics WHERE campaign_id=$1 GROUP BY platform`, [campaign_id]),
        query('SELECT * FROM promotional_events WHERE campaign_id=$1', [campaign_id]),
        query(`SELECT sentiment_class, COUNT(*) FROM sentiment_results
               WHERE campaign_id=$1 GROUP BY sentiment_class`, [campaign_id]),
        query('SELECT * FROM customer_segments WHERE campaign_id=$1', [campaign_id])
      ]);
      reportData = {
        ...reportData,
        campaign:  camp.rows[0],
        social:    social.rows,
        events:    events.rows,
        sentiment: sentiment.rows,
        segments:  segments.rows
      };
    }

    res.json({ success: true, data: { report: rows[0], content: reportData } });
  } catch (err) {
    logger.error('Report generate error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

async function list(req, res) {
  try {
    const { rows } = await query(
      `SELECT r.*, u.full_name AS created_by_name
       FROM reports r LEFT JOIN users u ON r.created_by = u.user_id
       ORDER BY r.created_at DESC LIMIT 50`
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

async function getOne(req, res) {
  try {
    const { rows } = await query('SELECT * FROM reports WHERE report_id=$1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, error: 'Report not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { generate, list, getOne };
