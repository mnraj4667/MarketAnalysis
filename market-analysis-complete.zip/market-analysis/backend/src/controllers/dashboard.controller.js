const { query } = require('../config/database');
const redis     = require('../config/redis');
const logger    = require('../utils/logger');

// GET /api/dashboard/summary
async function summary(req, res) {
  try {
    const cached = await redis.get('dashboard:summary');
    if (cached) return res.json({ success: true, data: { ...cached, fromCache: true } });

    const [campaigns, socialTotals, eventTotals, sentimentDist, recentCampaigns] = await Promise.all([
      query(`SELECT
               COUNT(*) FILTER (WHERE status='active')    AS active,
               COUNT(*) FILTER (WHERE status='completed') AS completed,
               COUNT(*) FILTER (WHERE status='paused')    AS paused,
               COUNT(*) AS total
             FROM campaigns`),
      query(`SELECT
               SUM(impressions) AS total_impressions,
               SUM(reach)       AS total_reach,
               SUM(clicks)      AS total_clicks,
               SUM(conversions) AS total_conversions,
               SUM(spend)       AS total_spend,
               AVG(engagement_rate) AS avg_engagement
             FROM social_media_metrics`),
      query(`SELECT
               SUM(actual_reach)   AS total_reach,
               SUM(conversions)    AS total_conversions,
               SUM(revenue)        AS total_revenue,
               AVG(satisfaction_score) AS avg_satisfaction
             FROM promotional_events`),
      query(`SELECT sentiment_class, COUNT(*) AS count
             FROM sentiment_results GROUP BY sentiment_class`),
      query(`SELECT c.campaign_id, c.name, c.channel, c.status, c.created_at,
                    COALESCE(SUM(s.conversions),0) AS conversions,
                    COALESCE(AVG(s.engagement_rate),0) AS engagement
             FROM campaigns c LEFT JOIN social_media_metrics s ON c.campaign_id = s.campaign_id
             GROUP BY c.campaign_id ORDER BY c.created_at DESC LIMIT 5`)
    ]);

    const sentMap = {};
    sentimentDist.rows.forEach(r => { sentMap[r.sentiment_class] = parseInt(r.count); });

    const data = {
      campaigns:      campaigns.rows[0],
      social_totals:  socialTotals.rows[0],
      event_totals:   eventTotals.rows[0],
      sentiment:      sentMap,
      recent_campaigns: recentCampaigns.rows,
      generated_at:   new Date().toISOString()
    };

    await redis.set('dashboard:summary', data, 300);
    res.json({ success: true, data });
  } catch (err) {
    logger.error('Dashboard summary error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/dashboard/channel-comparison
async function channelComparison(req, res) {
  try {
    const { from, to } = req.query;
    const dateFilter = from && to ? `AND metric_date BETWEEN '${from}' AND '${to}'` : '';

    const [social, events, classified] = await Promise.all([
      query(`SELECT
               platform,
               SUM(impressions) AS impressions, SUM(reach) AS reach,
               SUM(clicks) AS clicks, SUM(conversions) AS conversions,
               SUM(spend) AS spend, AVG(engagement_rate) AS engagement_rate,
               CASE WHEN SUM(spend)>0 THEN SUM(conversions)::float/SUM(spend) ELSE 0 END AS conv_per_dollar
             FROM social_media_metrics WHERE 1=1 ${dateFilter}
             GROUP BY platform ORDER BY SUM(impressions) DESC`),
      query(`SELECT
               'events' AS channel,
               SUM(actual_reach) AS reach, SUM(conversions) AS conversions,
               SUM(revenue) AS revenue, SUM(budget) AS spend,
               AVG(response_rate) AS response_rate
             FROM promotional_events`),
      query(`SELECT
               'classifieds' AS channel,
               SUM(impressions) AS impressions, SUM(responses) AS responses,
               SUM(cost) AS spend
             FROM classified_ads`)
    ]);

    res.json({
      success: true,
      data: {
        social_media:    social.rows,
        events:          events.rows[0],
        classifieds:     classified.rows[0]
      }
    });
  } catch (err) {
    logger.error('Channel comparison error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/dashboard/trend?metric=engagement_rate&days=30
async function trend(req, res) {
  try {
    const { metric = 'engagement_rate', days = 30, campaign_id } = req.query;
    const safeMetric = ['engagement_rate','impressions','reach','clicks','conversions','spend'].includes(metric)
      ? metric : 'engagement_rate';

    const conditions = [`metric_date >= NOW() - INTERVAL '${parseInt(days)} days'`];
    const params = [];
    if (campaign_id) { conditions.push(`campaign_id = $1`); params.push(campaign_id); }

    const { rows } = await query(
      `SELECT metric_date::text AS date, AVG(${safeMetric}) AS value, platform
       FROM social_media_metrics
       WHERE ${conditions.join(' AND ')}
       GROUP BY metric_date, platform ORDER BY metric_date`,
      params
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    logger.error('Trend error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

// GET /api/dashboard/roi
async function roi(req, res) {
  try {
    const { rows } = await query(
      `SELECT c.name, c.channel,
              COALESCE(s.spend,0) AS social_spend,
              COALESCE(e.revenue,0) AS revenue,
              COALESCE(e.conversions,0) + COALESCE(s.conversions,0) AS total_conversions,
              CASE WHEN COALESCE(s.spend,0)+COALESCE(e.budget,0) > 0
                   THEN COALESCE(e.revenue,0) / (COALESCE(s.spend,0)+COALESCE(e.budget,0))
                   ELSE 0 END AS roi_ratio
       FROM campaigns c
       LEFT JOIN (SELECT campaign_id, SUM(spend) AS spend, SUM(conversions) AS conversions
                  FROM social_media_metrics GROUP BY campaign_id) s ON c.campaign_id = s.campaign_id
       LEFT JOIN (SELECT campaign_id, SUM(revenue) AS revenue, SUM(budget) AS budget, SUM(conversions) AS conversions
                  FROM promotional_events GROUP BY campaign_id) e ON c.campaign_id = e.campaign_id
       ORDER BY roi_ratio DESC LIMIT 10`
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    logger.error('ROI error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
}

module.exports = { summary, channelComparison, trend, roi };
