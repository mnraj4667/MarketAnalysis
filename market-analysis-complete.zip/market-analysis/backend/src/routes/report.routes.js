const router = require('express').Router();
const ctrl   = require('../controllers/report.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.use(authenticate);
router.post('/generate', ctrl.generate);
router.get('/',          ctrl.list);
router.get('/:id',       ctrl.getOne);

module.exports = router;
