const router = require('express').Router();
const ctrl   = require('../controllers/data.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.use(authenticate);
router.post('/classifieds/upload', ctrl.upload.single('file'), ctrl.uploadClassifieds);
router.get('/classifieds',         ctrl.listClassifieds);
router.post('/social/import',      ctrl.importSocialMedia);
router.get('/social/metrics',      ctrl.getSocialMetrics);
router.post('/events',             ctrl.createEvent);
router.get('/events',              ctrl.listEvents);

module.exports = router;
