const dashRouter   = require('express').Router();
const reportRouter = require('express').Router();
const dashCtrl     = require('../controllers/dashboard.controller');
const reportCtrl   = require('../controllers/report.controller');
const { authenticate } = require('../middleware/auth.middleware');

dashRouter.use(authenticate);
dashRouter.get('/summary',            dashCtrl.summary);
dashRouter.get('/channel-comparison', dashCtrl.channelComparison);
dashRouter.get('/trend',              dashCtrl.trend);
dashRouter.get('/roi',                dashCtrl.roi);

reportRouter.use(authenticate);
reportRouter.post('/generate', reportCtrl.generate);
reportRouter.get('/',          reportCtrl.list);
reportRouter.get('/:id',       reportCtrl.getOne);

module.exports = { dashRouter, reportRouter };
