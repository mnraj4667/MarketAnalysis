const router = require('express').Router();
const ctrl   = require('../controllers/analytics.controller');
const { authenticate } = require('../middleware/auth.middleware');

router.use(authenticate);
router.post('/sentiment',              ctrl.runSentiment);
router.get('/sentiment/:campaignId',   ctrl.getSentiment);
router.post('/engagement',             ctrl.runEngagement);
router.post('/forecast',               ctrl.runForecast);
router.post('/segment',                ctrl.runSegmentation);
router.get('/segments/:campaignId',    ctrl.getSegments);
router.get('/performance/:campaignId', ctrl.getPerformance);

module.exports = router;
