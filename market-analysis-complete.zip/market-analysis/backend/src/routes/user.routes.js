// user.routes.js
const userRouter = require('express').Router();
const userCtrl   = require('../controllers/user.controller');
const { authenticate, requireRole } = require('../middleware/auth.middleware');

userRouter.use(authenticate);
userRouter.get('/',             requireRole('admin'), userCtrl.list);
userRouter.get('/:id',          userCtrl.getOne);
userRouter.put('/:id',          requireRole('admin'), userCtrl.update);
userRouter.post('/password',    userCtrl.changePassword);
userRouter.delete('/:id',       requireRole('admin'), userCtrl.remove);

module.exports = userRouter;
