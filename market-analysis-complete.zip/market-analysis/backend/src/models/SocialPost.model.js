const mongoose = require('mongoose');

const SocialPostSchema = new mongoose.Schema({
  campaign_id:     { type: String, index: true },
  platform:        { type: String, enum: ['facebook','instagram','twitter','linkedin','youtube'], required: true },
  post_id:         { type: String, unique: true, sparse: true },
  post_text:       { type: String, default: '' },
  post_date:       { type: Date, default: Date.now, index: true },
  impressions:     { type: Number, default: 0 },
  reach:           { type: Number, default: 0 },
  likes:           { type: Number, default: 0 },
  comments:        { type: Number, default: 0 },
  shares:          { type: Number, default: 0 },
  saves:           { type: Number, default: 0 },
  video_views:     { type: Number, default: 0 },
  engagement_rate: { type: Number, default: 0 },
  media_type:      { type: String, enum: ['text','image','video','carousel'], default: 'text' },
  hashtags:        [String],
  mentions:        [String],
  url:             String,
  sentiment:       { label: String, confidence: Number }
}, { timestamps: true });

SocialPostSchema.index({ campaign_id: 1, post_date: -1 });
SocialPostSchema.index({ platform: 1, post_date: -1 });

module.exports = mongoose.model('SocialPost', SocialPostSchema);
