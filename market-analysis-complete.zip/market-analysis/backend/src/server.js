require('dotenv').config();
const app = require('./app');
const { connectPostgres } = require('./config/database');
const { connectMongo }    = require('./config/mongodb');
const { connectRedis }    = require('./config/redis');
const logger = require('./utils/logger');

const PORT = process.env.PORT || 5000;

async function start() {
  try {
    await connectPostgres();
    await connectMongo();
    await connectRedis();

    app.listen(PORT, () => {
      logger.info(`🚀 Market Analysis API running on port ${PORT}`);
      logger.info(`📄 Swagger docs: http://localhost:${PORT}/api-docs`);
    });
  } catch (err) {
    logger.error('Failed to start server:', err);
    process.exit(1);
  }
}

start();
