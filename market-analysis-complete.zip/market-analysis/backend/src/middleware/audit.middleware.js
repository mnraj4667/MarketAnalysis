const { query } = require('../config/database');
const logger    = require('../utils/logger');

function audit(action, resourceType) {
  return async (req, res, next) => {
    const originalJson = res.json.bind(res);
    res.json = function(data) {
      // Fire and forget audit log
      if (req.user) {
        const resourceId = req.params.id || (data && data.data && data.data.id) || null;
        query(
          `INSERT INTO audit_logs (user_id, action, resource_type, resource_id, ip_address, user_agent, details)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [
            req.user.user_id, action, resourceType, resourceId,
            req.ip, req.get('user-agent'),
            JSON.stringify({ method: req.method, path: req.path, status: res.statusCode })
          ]
        ).catch(err => logger.error('Audit log failed:', err));
      }
      return originalJson(data);
    };
    next();
  };
}

module.exports = { audit };
