const jwt    = require('jsonwebtoken');
const redis  = require('../config/redis');
const { query } = require('../config/database');

async function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'No token provided' });
  }
  const token = header.split(' ')[1];

  // Check blacklist
  const blacklisted = await redis.exists(`blacklist:${token}`);
  if (blacklisted) {
    return res.status(401).json({ success: false, error: 'Token has been revoked' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'dev_secret');
    // Attach fresh user from DB
    const { rows } = await query(
      `SELECT u.user_id, u.email, u.full_name, u.is_active, r.role_name, r.permissions
       FROM users u JOIN roles r ON u.role_id = r.role_id
       WHERE u.user_id = $1`, [decoded.userId]
    );
    if (!rows.length || !rows[0].is_active) {
      return res.status(401).json({ success: false, error: 'User not found or inactive' });
    }
    req.user = rows[0];
    req.token = token;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ success: false, error: 'Token expired' });
    }
    return res.status(401).json({ success: false, error: 'Invalid token' });
  }
}

function authorize(...requiredPerms) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ success: false, error: 'Not authenticated' });
    const perms = req.user.permissions || [];
    if (perms.includes('*')) return next();
    const hasAll = requiredPerms.every(p => perms.includes(p));
    if (!hasAll) {
      return res.status(403).json({ success: false, error: 'Insufficient permissions' });
    }
    next();
  };
}

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ success: false, error: 'Not authenticated' });
    if (!roles.includes(req.user.role_name)) {
      return res.status(403).json({ success: false, error: `Role '${req.user.role_name}' is not permitted` });
    }
    next();
  };
}

module.exports = { authenticate, authorize, requireRole };
