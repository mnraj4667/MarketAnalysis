/**
 * Demo seed script – populates the database with realistic sample data
 * Run: node src/utils/seed.js
 */
require('dotenv').config()
const { Pool } = require('pg')

const pool = new Pool({
  connectionString: process.env.DATABASE_URL ||
    'postgresql://market_user:market_pass_2024@localhost:5432/market_analysis'
})

async function q(text, params) { return pool.query(text, params) }

async function seed() {
  console.log('🌱 Seeding demo data…')

  // Get admin user id
  const { rows: users } = await q(`SELECT user_id FROM users WHERE email='admin@marketai.com'`)
  const uid = users[0]?.user_id
  if (!uid) { console.error('Admin user not found – run migrations first'); process.exit(1) }

  // ── Campaigns ─────────────────────────────────────────────────
  const campaigns = [
    { name:'Summer Social 2025',      channel:'social_media', type:'digital',  budget:15000, status:'active',    seg:'18-35 urban professionals' },
    { name:'Q1 Classifieds Drive',    channel:'classifieds',  type:'print',    budget:4500,  status:'completed', seg:'Home buyers & renters' },
    { name:'Product Launch – ProMax', channel:'events',       type:'in-person',budget:25000, status:'active',    seg:'B2B enterprise clients' },
    { name:'Holiday Multi-Channel',   channel:'multi',        type:'seasonal', budget:32000, status:'paused',    seg:'All demographics' },
  ]
  const campIds = []
  for (const c of campaigns) {
    const { rows } = await q(
      `INSERT INTO campaigns (name, campaign_type, channel, start_date, end_date, budget, status, target_segment, created_by)
       VALUES ($1,$2,$3,'2025-01-01','2025-06-30',$4,$5,$6,$7)
       ON CONFLICT DO NOTHING RETURNING campaign_id`,
      [c.name, c.type, c.channel, c.budget, c.status, c.seg, uid]
    )
    if (rows.length) { campIds.push(rows[0].campaign_id); console.log(`  ✓ Campaign: ${c.name}`) }
  }

  if (!campIds.length) { console.log('Campaigns already exist – skipping'); await pool.end(); return }

  // ── Classified Ads ─────────────────────────────────────────────
  const adTexts = [
    { pub:'Daily Herald',    cat:'Real Estate',  text:'Spacious 3-bedroom house for sale – excellent location, great value, modern finishes throughout', imp:12400, resp:38, cost:245 },
    { pub:'City Times',      cat:'Automotive',   text:'2022 Toyota Camry – low mileage, excellent condition, full service history, one owner', imp:8900, resp:22, cost:180 },
    { pub:'Metro Gazette',   cat:'Employment',   text:'Senior Software Engineer wanted – competitive salary, flexible hours, outstanding team culture', imp:15600, resp:67, cost:320 },
    { pub:'Evening Post',    cat:'Real Estate',  text:'Luxury apartment for rent – city centre, fully furnished, stunning views, available immediately', imp:9800, resp:31, cost:195 },
    { pub:'Sunday Review',   cat:'Services',     text:'Professional cleaning services – trusted, reliable, affordable rates, free quote available today', imp:6200, resp:18, cost:120 },
  ]
  for (const a of adTexts) {
    await q(
      `INSERT INTO classified_ads (campaign_id, publication, category, ad_text, pub_date, impressions, responses, cost)
       VALUES ($1,$2,$3,$4,'2025-01-15',$5,$6,$7)`,
      [campIds[1], a.pub, a.cat, a.text, a.imp, a.resp, a.cost]
    )
  }
  console.log(`  ✓ ${adTexts.length} classified ads`)

  // ── Social Media Metrics ───────────────────────────────────────
  const platforms = ['facebook','instagram','twitter','linkedin']
  let metricCount = 0
  for (const platform of platforms) {
    for (let d = 0; d < 30; d++) {
      const date = new Date('2025-01-01')
      date.setDate(date.getDate() + d)
      const dateStr = date.toISOString().split('T')[0]
      const base = platform === 'instagram' ? 5.2 : platform === 'facebook' ? 3.8 : platform === 'linkedin' ? 2.1 : 0.8
      const noise = (Math.random() - 0.5) * 1.2
      const eng = Math.max(0.1, base + noise + Math.sin(d * 0.4) * 0.5)
      await q(
        `INSERT INTO social_media_metrics
         (campaign_id, platform, metric_date, impressions, reach, clicks, likes, comments, shares, saves, engagement_rate, spend, conversions)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
         ON CONFLICT (campaign_id, platform, metric_date) DO NOTHING`,
        [
          campIds[0], platform, dateStr,
          Math.round(40000 + Math.random() * 20000),
          Math.round(32000 + Math.random() * 15000),
          Math.round(800  + Math.random() * 600),
          Math.round(1200 + Math.random() * 800),
          Math.round(180  + Math.random() * 120),
          Math.round(95   + Math.random() * 60),
          Math.round(220  + Math.random() * 150),
          +eng.toFixed(4),
          +(250 + Math.random() * 150).toFixed(2),
          Math.round(25 + Math.random() * 40)
        ]
      )
      metricCount++
    }
  }
  console.log(`  ✓ ${metricCount} social media metric rows`)

  // ── Promotional Events ─────────────────────────────────────────
  const events = [
    { name:'ProMax Launch Event', type:'product_launch', loc:'New York Convention Center', reach:2400, leads:186, conv:42, rev:84000, sat:4.3 },
    { name:'Partner Summit Q1',   type:'conference',     loc:'Chicago Marriott',           reach:850,  leads:94,  conv:28, rev:56000, sat:4.6 },
    { name:'Webinar: AI Trends',  type:'webinar',        loc:'Online',                     reach:3200, leads:412, conv:67, rev:33500, sat:4.1 },
  ]
  for (const e of events) {
    await q(
      `INSERT INTO promotional_events
       (campaign_id, event_name, event_type, start_date, end_date, location, budget, actual_reach, leads_generated, conversions, revenue, satisfaction_score, created_by)
       VALUES ($1,$2,$3,'2025-02-01','2025-02-03',$4,20000,$5,$6,$7,$8,$9,$10)`,
      [campIds[2], e.name, e.type, e.loc, e.reach, e.leads, e.conv, e.rev, e.sat, uid]
    )
  }
  console.log(`  ✓ ${events.length} promotional events`)

  // ── Sentiment Results (sample) ─────────────────────────────────
  const sentiments = [
    ['positive', 0.92, 0.88, 0.06, 0.06],
    ['positive', 0.87, 0.83, 0.09, 0.08],
    ['negative', 0.78, 0.11, 0.75, 0.14],
    ['neutral',  0.71, 0.28, 0.23, 0.49],
    ['positive', 0.95, 0.93, 0.03, 0.04],
    ['negative', 0.81, 0.08, 0.79, 0.13],
    ['positive', 0.89, 0.86, 0.07, 0.07],
    ['neutral',  0.68, 0.32, 0.19, 0.49],
    ['positive', 0.91, 0.89, 0.05, 0.06],
    ['positive', 0.85, 0.82, 0.10, 0.08],
  ]
  const { rows: ads } = await q('SELECT ad_id FROM classified_ads LIMIT 10')
  for (let i = 0; i < ads.length && i < sentiments.length; i++) {
    const [cls, conf, pos, neg, neu] = sentiments[i]
    await q(
      `INSERT INTO sentiment_results (source_id, source_type, campaign_id, sentiment_class, confidence, positive_score, negative_score, neutral_score)
       VALUES ($1,'classified_ad',$2,$3,$4,$5,$6,$7)`,
      [ads[i].ad_id, campIds[1], cls, conf, pos, neg, neu]
    )
  }
  console.log('  ✓ Sample sentiment results')

  await pool.end()
  console.log('\n✅ Demo data seeded successfully!')
  console.log('   Open http://localhost:3000 and log in with admin@marketai.com / Admin@2024')
}

seed().catch(err => { console.error('Seed failed:', err.message); process.exit(1) })
