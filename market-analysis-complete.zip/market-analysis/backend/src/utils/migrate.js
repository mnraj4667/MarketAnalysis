/**
 * Migration runner – applies all SQL files in /database/migrations
 * Run: node src/utils/migrate.js
 */
require('dotenv').config()
const { Pool } = require('pg')
const fs   = require('fs')
const path = require('path')

const pool = new Pool({
  connectionString: process.env.DATABASE_URL ||
    'postgresql://market_user:market_pass_2024@localhost:5432/market_analysis'
})

async function migrate() {
  const client = await pool.connect()
  try {
    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migrations (
        id         SERIAL PRIMARY KEY,
        filename   VARCHAR(255) UNIQUE NOT NULL,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `)

    // Find migration files
    const migrationsDir = path.join(__dirname, '../../../database/migrations')
    if (!fs.existsSync(migrationsDir)) {
      console.warn('No migrations directory found at', migrationsDir)
      return
    }

    const files = fs.readdirSync(migrationsDir)
      .filter(f => f.endsWith('.sql'))
      .sort()

    for (const file of files) {
      const { rows } = await client.query(
        'SELECT id FROM _migrations WHERE filename = $1', [file]
      )
      if (rows.length) {
        console.log(`  ⏭  Already applied: ${file}`)
        continue
      }

      console.log(`  ▶  Applying: ${file}`)
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8')
      await client.query(sql)
      await client.query('INSERT INTO _migrations (filename) VALUES ($1)', [file])
      console.log(`  ✅ Applied: ${file}`)
    }

    console.log('\n✅ All migrations complete')
  } catch (err) {
    console.error('Migration failed:', err.message)
    process.exit(1)
  } finally {
    client.release()
    await pool.end()
  }
}

migrate()
