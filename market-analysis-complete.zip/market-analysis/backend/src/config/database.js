const { Pool } = require('pg');
const logger   = require('../utils/logger');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://market_user:market_pass_2024@localhost:5432/market_analysis',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

pool.on('error', (err) => logger.error('PG pool error:', err));

async function connectPostgres() {
  const client = await pool.connect();
  logger.info('✅ PostgreSQL connected');
  client.release();
}

async function query(text, params) {
  const start = Date.now();
  try {
    const res = await pool.query(text, params);
    const duration = Date.now() - start;
    if (duration > 1000) logger.warn(`Slow query (${duration}ms): ${text}`);
    return res;
  } catch (err) {
    logger.error('DB query error:', { query: text, error: err.message });
    throw err;
  }
}

async function getClient() {
  const client = await pool.connect();
  const originalQuery = client.query.bind(client);
  const release = client.release.bind(client);
  let released = false;
  client.release = () => {
    if (!released) { released = true; release(); }
  };
  // auto-release after 5s to guard against leaks
  setTimeout(() => { if (!released) { logger.warn('DB client not released – forcing release'); client.release(); } }, 5000);
  return client;
}

module.exports = { connectPostgres, query, getClient, pool };
