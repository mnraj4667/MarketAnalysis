const mongoose = require('mongoose');
const logger   = require('../utils/logger');

async function connectMongo() {
  const uri = process.env.MONGODB_URI || 'mongodb://market_user:market_pass_2024@localhost:27017/market_social?authSource=admin';
  await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
  logger.info('✅ MongoDB connected');
}

mongoose.connection.on('error', err => logger.error('MongoDB error:', err));
mongoose.connection.on('disconnected', () => logger.warn('MongoDB disconnected'));

module.exports = { connectMongo };
