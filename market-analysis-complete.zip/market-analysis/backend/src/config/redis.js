const { createClient } = require('redis');
const logger = require('../utils/logger');

let client;

async function connectRedis() {
  client = createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379',
    socket: { reconnectStrategy: retries => Math.min(retries * 100, 3000) }
  });
  client.on('error',  err  => logger.error('Redis error:', err));
  client.on('ready',  ()   => logger.info('✅ Redis connected'));
  await client.connect();
}

function getClient() {
  if (!client) throw new Error('Redis client not initialized');
  return client;
}

async function set(key, value, ttlSeconds) {
  const c = getClient();
  const val = typeof value === 'object' ? JSON.stringify(value) : String(value);
  if (ttlSeconds) return c.setEx(key, ttlSeconds, val);
  return c.set(key, val);
}

async function get(key) {
  const val = await getClient().get(key);
  if (!val) return null;
  try { return JSON.parse(val); } catch { return val; }
}

async function del(key)          { return getClient().del(key); }
async function exists(key)       { return getClient().exists(key); }
async function expire(key, secs) { return getClient().expire(key, secs); }
async function incr(key)         { return getClient().incr(key); }

module.exports = { connectRedis, getClient, set, get, del, exists, expire, incr };
