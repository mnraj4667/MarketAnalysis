/**
 * Backend API Tests
 * Run: npm test  (requires jest + supertest)
 *
 * These tests use an in-memory mock of the DB so no live database is needed.
 */

// ── Mock all external dependencies ──────────────────────────
jest.mock('../src/config/database', () => ({
  query: jest.fn(),
  getClient: jest.fn(),
  connectPostgres: jest.fn().mockResolvedValue(true)
}))
jest.mock('../src/config/mongodb', () => ({
  connectMongo: jest.fn().mockResolvedValue(true)
}))
jest.mock('../src/config/redis', () => ({
  connectRedis: jest.fn().mockResolvedValue(true),
  get: jest.fn().mockResolvedValue(null),
  set: jest.fn().mockResolvedValue(true),
  del: jest.fn().mockResolvedValue(true),
  exists: jest.fn().mockResolvedValue(0)
}))

const request = require('supertest')
const bcrypt  = require('bcryptjs')
const jwt     = require('jsonwebtoken')
const app     = require('../src/app')
const db      = require('../src/config/database')
const redis   = require('../src/config/redis')

const JWT_SECRET = 'dev_secret'
process.env.JWT_SECRET = JWT_SECRET

// ── Helper: create a valid JWT token ────────────────────────
function makeToken(overrides = {}) {
  return jwt.sign(
    { userId: 'user-1', email: 'admin@test.com', role: 'admin', ...overrides },
    JWT_SECRET,
    { expiresIn: '1h' }
  )
}

// ── Mock user returned from DB ───────────────────────────────
const MOCK_USER = {
  user_id:    'user-1',
  email:      'admin@test.com',
  full_name:  'Test Admin',
  role_name:  'admin',
  is_active:  true,
  permissions: ['*']
}

// ── Auth Tests ───────────────────────────────────────────────
describe('POST /api/auth/login', () => {
  const hash = bcrypt.hashSync('TestPass@1', 10)

  beforeEach(() => {
    db.query.mockReset()
    redis.exists.mockResolvedValue(0)
  })

  test('returns 400 when body is missing', async () => {
    const res = await request(app).post('/api/auth/login').send({})
    expect(res.status).toBe(400)
    expect(res.body.success).toBe(false)
  })

  test('returns 401 for unknown email', async () => {
    db.query.mockResolvedValueOnce({ rows: [] })
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'nobody@test.com', password: 'anything' })
    expect(res.status).toBe(401)
  })

  test('returns 401 for wrong password', async () => {
    db.query.mockResolvedValueOnce({ rows: [{ ...MOCK_USER, password_hash: hash }] })
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'admin@test.com', password: 'WrongPass!' })
    expect(res.status).toBe(401)
  })

  test('returns 200 with tokens on valid credentials', async () => {
    db.query
      .mockResolvedValueOnce({ rows: [{ ...MOCK_USER, password_hash: hash }] })
      .mockResolvedValueOnce({ rows: [] })  // UPDATE last_login
    redis.set.mockResolvedValue(true)

    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'admin@test.com', password: 'TestPass@1' })

    expect(res.status).toBe(200)
    expect(res.body.success).toBe(true)
    expect(res.body.data).toHaveProperty('accessToken')
    expect(res.body.data).toHaveProperty('refreshToken')
    expect(res.body.data.user.email).toBe('admin@test.com')
  })
})

describe('GET /api/auth/me', () => {
  test('returns 401 without token', async () => {
    const res = await request(app).get('/api/auth/me')
    expect(res.status).toBe(401)
  })

  test('returns user profile with valid token', async () => {
    redis.exists.mockResolvedValue(0)
    db.query.mockResolvedValueOnce({ rows: [MOCK_USER] })

    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${makeToken()}`)

    expect(res.status).toBe(200)
    expect(res.body.data.email).toBe('admin@test.com')
  })
})

// ── Campaign Tests ───────────────────────────────────────────
describe('GET /api/campaigns', () => {
  const token = makeToken()

  beforeEach(() => {
    db.query.mockReset()
    redis.exists.mockResolvedValue(0)
    db.query.mockResolvedValueOnce({ rows: [MOCK_USER] })  // auth middleware
  })

  test('returns 200 with campaign list', async () => {
    db.query
      .mockResolvedValueOnce({ rows: [
        { campaign_id: 'c1', name: 'Test Campaign', channel: 'social_media', status: 'active' }
      ]})
      .mockResolvedValueOnce({ rows: [{ count: '1' }] })

    const res = await request(app)
      .get('/api/campaigns')
      .set('Authorization', `Bearer ${token}`)

    expect(res.status).toBe(200)
    expect(res.body.success).toBe(true)
    expect(Array.isArray(res.body.data)).toBe(true)
  })
})

describe('POST /api/campaigns', () => {
  const token = makeToken()

  beforeEach(() => {
    db.query.mockReset()
    redis.exists.mockResolvedValue(0)
    db.query.mockResolvedValueOnce({ rows: [MOCK_USER] })
  })

  test('returns 400 when name is missing', async () => {
    const res = await request(app)
      .post('/api/campaigns')
      .set('Authorization', `Bearer ${token}`)
      .send({ channel: 'social_media' })

    expect(res.status).toBe(400)
    expect(res.body.success).toBe(false)
  })

  test('creates campaign with valid data', async () => {
    db.query.mockResolvedValueOnce({
      rows: [{ campaign_id: 'new-c1', name: 'My Campaign', status: 'active' }]
    })

    const res = await request(app)
      .post('/api/campaigns')
      .set('Authorization', `Bearer ${token}`)
      .send({ name: 'My Campaign', channel: 'social_media', budget: 5000 })

    expect(res.status).toBe(201)
    expect(res.body.data.name).toBe('My Campaign')
  })
})

// ── Health Check ─────────────────────────────────────────────
describe('GET /health', () => {
  test('returns 200 ok', async () => {
    const res = await request(app).get('/health')
    expect(res.status).toBe(200)
    expect(res.body.status).toBe('ok')
  })
})

// ── 404 Handler ──────────────────────────────────────────────
describe('404 handler', () => {
  test('returns 404 for unknown routes', async () => {
    const res = await request(app).get('/api/nonexistent')
    expect(res.status).toBe(404)
    expect(res.body.success).toBe(false)
  })
})
