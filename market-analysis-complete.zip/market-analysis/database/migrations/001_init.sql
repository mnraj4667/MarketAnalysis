-- ============================================================
-- AI Market Analysis System – PostgreSQL Schema
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ── Roles ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roles (
    role_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role_name VARCHAR(50) UNIQUE NOT NULL,
    permissions JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO roles (role_name, permissions) VALUES
  ('admin',   '["*"]'),
  ('analyst', '["data:read","data:write","analytics:run","reports:read","reports:write","dashboard:read"]'),
  ('manager', '["data:read","analytics:read","reports:read","dashboard:read"]'),
  ('viewer',  '["dashboard:read","reports:read"]')
ON CONFLICT (role_name) DO NOTHING;

-- ── Users ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    user_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email         VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(255) NOT NULL,
    role_id       UUID REFERENCES roles(role_id),
    is_active     BOOLEAN DEFAULT TRUE,
    last_login    TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Campaigns ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS campaigns (
    campaign_id   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name          VARCHAR(255) NOT NULL,
    description   TEXT,
    campaign_type VARCHAR(100),
    channel       VARCHAR(50) CHECK (channel IN ('classifieds','social_media','events','multi')),
    start_date    DATE,
    end_date      DATE,
    budget        DECIMAL(15,2),
    status        VARCHAR(50) DEFAULT 'active' CHECK (status IN ('active','paused','completed','draft')),
    target_segment VARCHAR(255),
    created_by    UUID REFERENCES users(user_id),
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- ── Classified Advertisements ────────────────────────────────
CREATE TABLE IF NOT EXISTS classified_ads (
    ad_id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campaign_id     UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    publication     VARCHAR(255),
    category        VARCHAR(100),
    ad_text         TEXT,
    contact_info    VARCHAR(255),
    pricing_tier    VARCHAR(50),
    location        VARCHAR(255),
    pub_date        DATE,
    ad_dimensions   VARCHAR(100),
    frequency       VARCHAR(50),
    impressions     INTEGER DEFAULT 0,
    responses       INTEGER DEFAULT 0,
    cost            DECIMAL(10,2),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_classified_ads_campaign ON classified_ads(campaign_id, pub_date);
CREATE INDEX IF NOT EXISTS idx_classified_ads_text ON classified_ads USING gin(to_tsvector('english', COALESCE(ad_text,'')));

-- ── Promotional Events ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS promotional_events (
    event_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campaign_id     UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    event_name      VARCHAR(255) NOT NULL,
    event_type      VARCHAR(100),
    start_date      DATE,
    end_date        DATE,
    location        VARCHAR(255),
    target_segment  VARCHAR(255),
    channels_used   JSONB DEFAULT '[]',
    budget          DECIMAL(15,2),
    actual_reach    INTEGER DEFAULT 0,
    estimated_reach INTEGER DEFAULT 0,
    response_rate   DECIMAL(5,2),
    leads_generated INTEGER DEFAULT 0,
    conversions     INTEGER DEFAULT 0,
    revenue         DECIMAL(15,2) DEFAULT 0,
    satisfaction_score DECIMAL(3,2),
    nps_score       INTEGER,
    notes           TEXT,
    created_by      UUID REFERENCES users(user_id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_promo_events_campaign ON promotional_events(campaign_id, start_date);

-- ── Sentiment Results ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sentiment_results (
    result_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_id       UUID NOT NULL,
    source_type     VARCHAR(50) CHECK (source_type IN ('classified_ad','social_post','event_feedback')),
    campaign_id     UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    sentiment_class VARCHAR(20) CHECK (sentiment_class IN ('positive','negative','neutral')),
    confidence      DECIMAL(5,4),
    positive_score  DECIMAL(5,4),
    negative_score  DECIMAL(5,4),
    neutral_score   DECIMAL(5,4),
    aspects         JSONB DEFAULT '{}',
    analyzed_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sentiment_campaign ON sentiment_results(campaign_id, sentiment_class);
CREATE INDEX IF NOT EXISTS idx_sentiment_source ON sentiment_results(source_id, source_type);

-- ── Engagement Results ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS engagement_results (
    result_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campaign_id     UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    channel         VARCHAR(50),
    engagement_rate DECIMAL(8,4),
    top_factors     JSONB DEFAULT '[]',
    recommendations JSONB DEFAULT '[]',
    analyzed_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ── Forecast Results ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS forecast_results (
    result_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campaign_id     UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    metric_name     VARCHAR(100),
    horizon_days    INTEGER,
    forecast_values JSONB DEFAULT '[]',
    confidence_upper JSONB DEFAULT '[]',
    confidence_lower JSONB DEFAULT '[]',
    mape            DECIMAL(8,4),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Customer Segments ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS customer_segments (
    segment_id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campaign_id     UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    segment_name    VARCHAR(255),
    segment_label   VARCHAR(100),
    characteristics JSONB DEFAULT '{}',
    member_count    INTEGER DEFAULT 0,
    percentage      DECIMAL(5,2),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ── Reports ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reports (
    report_id    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title        VARCHAR(255) NOT NULL,
    report_type  VARCHAR(100),
    campaign_id  UUID REFERENCES campaigns(campaign_id) ON DELETE SET NULL,
    created_by   UUID REFERENCES users(user_id),
    format       VARCHAR(20) CHECK (format IN ('pdf','excel','csv','json')),
    file_path    VARCHAR(500),
    parameters   JSONB DEFAULT '{}',
    status       VARCHAR(50) DEFAULT 'pending',
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── Analytics Jobs ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS analytics_jobs (
    job_id       UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_type     VARCHAR(100) NOT NULL,
    campaign_id  UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    status       VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending','running','completed','failed')),
    progress     INTEGER DEFAULT 0,
    parameters   JSONB DEFAULT '{}',
    result_id    UUID,
    error_msg    TEXT,
    started_at   TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_by   UUID REFERENCES users(user_id),
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ── Audit Logs ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID REFERENCES users(user_id) ON DELETE SET NULL,
    action        VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100),
    resource_id   UUID,
    ip_address    INET,
    user_agent    TEXT,
    details       JSONB DEFAULT '{}',
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit_logs(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_time ON audit_logs USING brin(created_at);

-- ── Social Media Metrics (daily aggregates) ──────────────────
CREATE TABLE IF NOT EXISTS social_media_metrics (
    metric_id     UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    campaign_id   UUID REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
    platform      VARCHAR(50),
    metric_date   DATE,
    impressions   BIGINT DEFAULT 0,
    reach         BIGINT DEFAULT 0,
    clicks        INTEGER DEFAULT 0,
    likes         INTEGER DEFAULT 0,
    comments      INTEGER DEFAULT 0,
    shares        INTEGER DEFAULT 0,
    saves         INTEGER DEFAULT 0,
    video_views   INTEGER DEFAULT 0,
    engagement_rate DECIMAL(8,4),
    cost_per_click  DECIMAL(10,4),
    spend         DECIMAL(15,2),
    conversions   INTEGER DEFAULT 0,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(campaign_id, platform, metric_date)
);

CREATE INDEX IF NOT EXISTS idx_social_metrics_campaign ON social_media_metrics(campaign_id, metric_date);

-- ── Seed: default admin user (password: Admin@2024) ─────────
-- bcrypt hash of "Admin@2024"
INSERT INTO users (email, password_hash, full_name, role_id)
SELECT
    'admin@marketai.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PVzfWS',
    'System Administrator',
    r.role_id
FROM roles r WHERE r.role_name = 'admin'
ON CONFLICT (email) DO NOTHING;

-- Seed demo analyst
INSERT INTO users (email, password_hash, full_name, role_id)
SELECT
    'analyst@marketai.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.PVzfWS',
    'Demo Analyst',
    r.role_id
FROM roles r WHERE r.role_name = 'analyst'
ON CONFLICT (email) DO NOTHING;
