"""
AI Service Unit Tests  –  uses stdlib unittest (no extra install needed)
Run inside container:  python -m pytest tests/ -v
Run locally:           python -m unittest tests.test_models -v
"""
import sys, os, math, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from models.sentiment_model  import SentimentAnalyzer
from models.engagement_model import EngagementAnalyzer
from models.forecast_model   import ForecastModel
from models.segment_model    import SegmentationModel


class TestSentimentAnalyzer(unittest.TestCase):
    def setUp(self):
        self.model = SentimentAnalyzer()

    def test_positive_text(self):
        r = self.model.predict(["This product is excellent amazing quality, highly recommend!"])[0]
        self.assertEqual(r["label"], "positive")
        self.assertGreater(r["confidence"], 0.5)

    def test_negative_text(self):
        r = self.model.predict(["Terrible broken product, waste of money, avoid"])[0]
        self.assertEqual(r["label"], "negative")
        self.assertGreater(r["confidence"], 0.5)

    def test_empty_text(self):
        r = self.model.predict([""])[0]
        self.assertEqual(r["label"], "neutral")

    def test_batch_length(self):
        texts = ["Great service!", "Very bad experience.", "Average product."]
        self.assertEqual(len(self.model.predict(texts)), 3)

    def test_scores_sum_approx_one(self):
        r = self.model.predict(["Good product"])[0]
        total = r["positive"] + r["negative"] + r["neutral"]
        self.assertAlmostEqual(total, 1.0, delta=0.1)

    def test_confidence_in_range(self):
        for text in ["Good", "Bad", "Okay"]:
            r = self.model.predict([text])[0]
            self.assertGreaterEqual(r["confidence"], 0.0)
            self.assertLessEqual(r["confidence"], 1.0)

    def test_all_keys_present(self):
        r = self.model.predict(["test"])[0]
        for key in ("label", "confidence", "positive", "negative", "neutral"):
            self.assertIn(key, r)


class TestEngagementAnalyzer(unittest.TestCase):
    def setUp(self):
        self.model = EngagementAnalyzer()

    def test_empty_returns_zero(self):
        r = self.model.analyze([])
        self.assertEqual(r["avg_engagement"], 0)

    def test_recommendations_present(self):
        r = self.model.analyze([])
        self.assertGreater(len(r["recommendations"]), 0)

    def test_below_benchmark_flagged(self):
        r = self.model.analyze([{"platform": "facebook", "avg_rate": 0.3}])
        self.assertEqual(r["platform_analysis"][0]["status"], "below_benchmark")

    def test_above_benchmark_flagged(self):
        r = self.model.analyze([{"platform": "instagram", "avg_rate": 9.0}])
        self.assertEqual(r["platform_analysis"][0]["status"], "above_benchmark")

    def test_avg_calculated(self):
        r = self.model.analyze([{"platform":"facebook","avg_rate":3.0},
                                 {"platform":"instagram","avg_rate":5.0}])
        self.assertAlmostEqual(r["avg_engagement"], 4.0, delta=0.01)

    def test_top_factors_structure(self):
        r = self.model.analyze([{"platform": "linkedin", "avg_rate": 2.0}])
        for f in r["top_factors"]:
            self.assertIn("factor", f)
            self.assertIn("importance", f)


class TestForecastModel(unittest.TestCase):
    def setUp(self):
        self.model = ForecastModel()

    def _series(self, n=30):
        return [{"date": f"2025-01-{i+1:02d}", "value": 3.5 + math.sin(i * 0.4) + 0.05*i}
                for i in range(min(n, 28))]

    def test_length_matches_horizon(self):
        for h in (7, 14, 30):
            r = self.model.predict(self._series(28), horizon_days=h)
            self.assertEqual(len(r["forecast"]), h)

    def test_result_keys(self):
        r = self.model.predict(self._series(20), horizon_days=7)
        for key in ("forecast", "upper", "lower", "mape"):
            self.assertIn(key, r)

    def test_values_non_negative(self):
        r = self.model.predict(self._series(28), horizon_days=14)
        for p in r["forecast"]:
            self.assertGreaterEqual(p["value"], 0)

    def test_upper_gte_lower(self):
        r = self.model.predict(self._series(28), horizon_days=14)
        for u, l in zip(r["upper"], r["lower"]):
            self.assertGreaterEqual(u["value"], l["value"])

    def test_dates_sequential(self):
        r = self.model.predict(self._series(28), horizon_days=5)
        dates = [p["date"] for p in r["forecast"]]
        self.assertEqual(dates, sorted(dates))
        self.assertEqual(len(set(dates)), 5)


class TestSegmentationModel(unittest.TestCase):
    def setUp(self):
        self.model = SegmentationModel()

    def test_synthetic_not_empty(self):
        segs = self.model.segment([], n_clusters=6)
        self.assertGreater(len(segs), 0)

    def test_segment_keys(self):
        for s in self.model.segment([], n_clusters=6):
            for key in ("name", "label", "count", "percentage", "characteristics"):
                self.assertIn(key, s)

    def test_percentages_sum_near_100(self):
        total = sum(s["percentage"] for s in self.model.segment([], n_clusters=6))
        self.assertAlmostEqual(total, 100, delta=5)

    def test_valid_labels(self):
        VALID = {"high_digital","traditional","event_driven","price_sensitive","loyal","passive"}
        for s in self.model.segment([], n_clusters=6):
            self.assertIn(s["label"], VALID)

    def test_characteristics_keys(self):
        for s in self.model.segment([], n_clusters=6):
            self.assertIn("avg_engagement",  s["characteristics"])
            self.assertIn("avg_conversions", s["characteristics"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
