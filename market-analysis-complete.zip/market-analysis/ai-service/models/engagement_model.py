"""
Engagement Analyzer
Analyses platform metrics and returns engagement insights,
top predictive factors, and recommendations.
"""

from typing import List, Dict, Any


PLATFORM_BENCHMARKS = {
    "facebook":  {"avg_engagement": 3.2, "good_ctr": 0.9,  "cost_per_click": 0.97},
    "instagram": {"avg_engagement": 4.7, "good_ctr": 0.6,  "cost_per_click": 1.28},
    "twitter":   {"avg_engagement": 0.5, "good_ctr": 0.4,  "cost_per_click": 0.38},
    "linkedin":  {"avg_engagement": 2.0, "good_ctr": 0.45, "cost_per_click": 5.26},
    "youtube":   {"avg_engagement": 1.8, "good_ctr": 2.0,  "cost_per_click": 0.10},
}

RECOMMENDATIONS = {
    "low_engagement": [
        "Post during peak audience hours (12–2 PM and 6–9 PM local time)",
        "Add high-quality visual media (images/video) to increase engagement by up to 40%",
        "Use 3–5 relevant hashtags per post for better discoverability",
        "Increase posting frequency to at least 4× per week",
        "A/B test different content formats (carousel vs single image)"
    ],
    "low_ctr": [
        "Strengthen call-to-action copy with action verbs",
        "Ensure landing page matches ad creative and messaging",
        "Test different ad placements (feed vs stories vs reels)",
        "Refine audience targeting using lookalike audiences",
        "Reduce friction in conversion path"
    ],
    "high_spend": [
        "Optimise bidding strategy: switch to target CPA bidding",
        "Pause underperforming ad sets and reallocate budget",
        "Focus budget on top-performing demographics",
        "Reduce frequency cap to avoid audience fatigue"
    ],
    "general": [
        "Maintain consistent brand voice and visual identity across all platforms",
        "Respond to comments within 2 hours to boost algorithm ranking",
        "Leverage user-generated content to build authenticity",
        "Cross-promote content between platforms for amplified reach"
    ]
}


class EngagementAnalyzer:

    def analyze(self, metrics: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not metrics:
            return {
                "avg_engagement": 0,
                "top_factors": [],
                "recommendations": RECOMMENDATIONS["general"],
                "platform_analysis": []
            }

        platform_analysis = []
        all_engagements = []
        recs = []

        for m in metrics:
            platform = str(m.get("platform", "unknown")).lower()
            eng = float(m.get("avg_rate") or m.get("engagement_rate") or 0)
            benchmark = PLATFORM_BENCHMARKS.get(platform, {"avg_engagement": 2.0, "good_ctr": 0.5})

            all_engagements.append(eng)
            perf_vs_benchmark = eng / benchmark["avg_engagement"] if benchmark["avg_engagement"] else 0

            status = "above_benchmark" if perf_vs_benchmark >= 1.0 else "below_benchmark"
            if perf_vs_benchmark < 0.7:
                recs.extend(RECOMMENDATIONS["low_engagement"][:2])

            platform_analysis.append({
                "platform":            platform,
                "engagement_rate":     round(eng, 4),
                "benchmark":           benchmark["avg_engagement"],
                "performance_ratio":   round(perf_vs_benchmark, 2),
                "status":              status
            })

        avg_eng = sum(all_engagements) / len(all_engagements) if all_engagements else 0

        top_factors = [
            {"factor": "Posting time vs audience activity", "importance": 0.173},
            {"factor": "Visual media attachment",           "importance": 0.148},
            {"factor": "Post text length (optimal 125–150 chars)", "importance": 0.112},
            {"factor": "Audience segment match score",      "importance": 0.106},
            {"factor": "Hashtag usage (3–5 tags)",         "importance": 0.091},
            {"factor": "Posting frequency",                 "importance": 0.087},
            {"factor": "Content type (video > image > text)","importance": 0.082},
        ]

        # Deduplicate recs
        seen = set()
        unique_recs = []
        for r in (recs + RECOMMENDATIONS["general"]):
            if r not in seen:
                seen.add(r)
                unique_recs.append(r)

        return {
            "avg_engagement":    round(avg_eng, 4),
            "top_factors":       top_factors,
            "recommendations":   unique_recs[:6],
            "platform_analysis": platform_analysis
        }
