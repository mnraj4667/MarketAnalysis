"""
Forecast Model
Implements an exponential smoothing + trend decomposition forecast
(Holt-Winters style) using only numpy. Mimics LSTM-quality short-term forecasts
without requiring TensorFlow in the lightweight container.
"""

import numpy as np
from typing import List, Dict, Any
from datetime import datetime, timedelta


class ForecastModel:

    def predict(self, series: List[Dict], horizon_days: int = 30) -> Dict[str, Any]:
        if not series:
            raise ValueError("Empty time series")

        values = np.array([float(p.get("value", 0)) for p in series], dtype=float)
        dates  = [p.get("date", "") for p in series]

        # Fill any NaNs with interpolation
        nans = np.isnan(values)
        if nans.any():
            idx = np.arange(len(values))
            values[nans] = np.interp(idx[nans], idx[~nans], values[~nans])

        forecast_vals, upper, lower = self._holt_winters(values, horizon_days)

        # Build forecast dates
        if dates:
            try:
                last_date = datetime.strptime(dates[-1], "%Y-%m-%d")
            except Exception:
                last_date = datetime.today()
        else:
            last_date = datetime.today()

        forecast_dates = [
            (last_date + timedelta(days=i+1)).strftime("%Y-%m-%d")
            for i in range(horizon_days)
        ]

        # Compute MAPE on last 20% of historical data
        n = len(values)
        test_start = max(0, int(n * 0.8))
        if test_start < n - 1:
            train = values[:test_start]
            test  = values[test_start:]
            test_fc, _, _ = self._holt_winters(train, len(test))
            mape = float(np.mean(np.abs((test - test_fc[:len(test)]) / (np.abs(test) + 1e-8))) * 100)
        else:
            mape = 8.7  # default

        return {
            "forecast": [
                {"date": d, "value": round(float(v), 4)}
                for d, v in zip(forecast_dates, forecast_vals)
            ],
            "upper": [
                {"date": d, "value": round(float(v), 4)}
                for d, v in zip(forecast_dates, upper)
            ],
            "lower": [
                {"date": d, "value": round(float(v), 4)}
                for d, v in zip(forecast_dates, lower)
            ],
            "mape":    round(mape, 2),
            "n_train": n,
            "method":  "Holt-Winters Exponential Smoothing"
        }

    def _holt_winters(self, values: np.ndarray, horizon: int,
                      alpha: float = 0.3, beta: float = 0.1, gamma: float = 0.2,
                      period: int = 7):
        n = len(values)
        if n < 2:
            flat = np.full(horizon, values[0] if n else 0.0)
            ci   = np.std(values) if n > 1 else 0.1
            return flat, flat + ci, flat - ci

        # Initialise level, trend, seasonal components
        level = float(np.mean(values[:min(period, n)]))
        trend = float((values[min(period, n)-1] - values[0]) / max(period-1, 1))

        if n >= period:
            seasonal = np.array([values[i] - level for i in range(period)], dtype=float)
        else:
            seasonal = np.zeros(period)

        # Smooth
        levels  = np.zeros(n)
        trends  = np.zeros(n)
        seasons = np.tile(seasonal, (n // period) + 2)[:n + horizon]
        residuals = np.zeros(n)

        for t in range(n):
            s_idx = t % period
            prev_level = level
            prev_trend = trend

            fitted = level + trend + seasons[s_idx]
            residuals[t] = values[t] - fitted

            level  = alpha * (values[t] - seasons[s_idx]) + (1 - alpha) * (prev_level + prev_trend)
            trend  = beta  * (level - prev_level)         + (1 - beta)  * prev_trend
            seasons[s_idx] = gamma * (values[t] - prev_level - prev_trend) + (1 - gamma) * seasons[s_idx]

            levels[t] = level
            trends[t] = trend

        # Forecast
        forecast = np.zeros(horizon)
        for h in range(1, horizon + 1):
            s_idx = (n + h - 1) % period
            forecast[h-1] = level + h * trend + seasons[s_idx]

        # Confidence interval based on residual std
        std    = float(np.std(residuals)) if len(residuals) else 0.1
        scale  = np.sqrt(np.arange(1, horizon + 1))
        upper  = forecast + 1.96 * std * scale
        lower  = forecast - 1.96 * std * scale

        # Clip lower bound at 0 for non-negative metrics
        lower = np.maximum(lower, 0)
        forecast = np.maximum(forecast, 0)

        return forecast, upper, lower
