"""
AI-Enabled Market Analysis – Python AI Service
FastAPI application exposing ML inference endpoints.
Uses scikit-learn + numpy (no heavy GPU models needed to run locally).
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import numpy as np
import logging

from models.sentiment_model  import SentimentAnalyzer
from models.engagement_model import EngagementAnalyzer
from models.forecast_model   import ForecastModel
from models.segment_model    import SegmentationModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Market Analysis AI Service",
    description="ML inference endpoints for sentiment, engagement, forecasting and segmentation",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Initialise models at startup ─────────────────────────────
sentiment_model  = SentimentAnalyzer()
engagement_model = EngagementAnalyzer()
forecast_model   = ForecastModel()
segment_model    = SegmentationModel()

logger.info("All models initialised")


# ── Request / Response Schemas ───────────────────────────────
class SentimentRequest(BaseModel):
    texts: List[str]

class SentimentResult(BaseModel):
    label:      str
    confidence: float
    positive:   float
    negative:   float
    neutral:    float

class EngagementRequest(BaseModel):
    metrics: List[Dict[str, Any]]

class SeriesPoint(BaseModel):
    date:  str
    value: float

class ForecastRequest(BaseModel):
    series:       List[SeriesPoint]
    horizon_days: int = 30
    metric:       str = "engagement_rate"

class SegmentRequest(BaseModel):
    campaign_id: str
    metrics:     List[Dict[str, Any]]
    n_clusters:  int = 6


# ── Endpoints ─────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "models": ["sentiment", "engagement", "forecast", "segmentation"]}


@app.post("/sentiment", response_model=Dict[str, Any])
def run_sentiment(req: SentimentRequest):
    if not req.texts:
        raise HTTPException(400, "No texts provided")
    try:
        results = sentiment_model.predict(req.texts)
        return {"results": results, "total": len(results)}
    except Exception as e:
        logger.error(f"Sentiment error: {e}")
        raise HTTPException(500, str(e))


@app.post("/engagement", response_model=Dict[str, Any])
def run_engagement(req: EngagementRequest):
    try:
        analysis = engagement_model.analyze(req.metrics)
        return analysis
    except Exception as e:
        logger.error(f"Engagement error: {e}")
        raise HTTPException(500, str(e))


@app.post("/forecast", response_model=Dict[str, Any])
def run_forecast(req: ForecastRequest):
    try:
        series = [{"date": p.date, "value": p.value} for p in req.series]
        result = forecast_model.predict(series, req.horizon_days)
        return result
    except Exception as e:
        logger.error(f"Forecast error: {e}")
        raise HTTPException(500, str(e))


@app.post("/segment", response_model=Dict[str, Any])
def run_segment(req: SegmentRequest):
    try:
        result = segment_model.segment(req.metrics, req.n_clusters)
        return {"segments": result, "campaign_id": req.campaign_id}
    except Exception as e:
        logger.error(f"Segment error: {e}")
        raise HTTPException(500, str(e))
