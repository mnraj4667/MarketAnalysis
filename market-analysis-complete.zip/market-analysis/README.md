# AI-Enabled Market Analysis and Visualization System

A full-stack enterprise marketing analytics platform integrating newspaper classifieds, social media, and promotional event data with AI-driven sentiment analysis, trend forecasting, customer segmentation, and interactive dashboards.

---

## Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  React Frontend │────▶│  Node.js Backend  │────▶│  Python AI Svc  │
│  (port 3000)    │     │  (port 5000)      │     │  (port 8000)    │
└─────────────────┘     └──────────────────┘     └─────────────────┘
                                │                         │
                    ┌───────────┼───────────┐             │
                    ▼           ▼           ▼             │
               PostgreSQL    MongoDB     Redis            │
               (port 5432)  (port 27017)(port 6379)       │
```

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18, Vite, Tailwind CSS, Recharts |
| Backend API | Node.js 20, Express.js, JWT Auth |
| AI Service | Python 3.11, FastAPI, NumPy, scikit-learn |
| Relational DB | PostgreSQL 15 |
| Document DB | MongoDB 6 |
| Cache | Redis 7 |
| Container | Docker + Docker Compose |

---

## Quick Start (Docker – Recommended)

### Prerequisites

- [Docker Desktop](https://www.docker.com/products/docker-desktop/) (includes Docker Compose)
- 4 GB RAM minimum for containers
- Ports 3000, 5000, 8000, 5432, 27017, 6379 must be free

### 1. Clone / Extract

```bash
# If using git:
git clone <repo-url> market-analysis
cd market-analysis

# Or extract the zip:
unzip market-analysis.zip
cd market-analysis
```

### 2. Start all services

```bash
docker-compose up --build
```

This will:
- Build all 3 application images (backend, frontend, AI service)
- Pull PostgreSQL, MongoDB and Redis images
- Run the database migration automatically (creates all tables + seeds default users)
- Start all 5 services

**First build takes ~3–5 minutes.** Subsequent starts take ~20 seconds.

### 3. Open the app

| Service | URL |
|---------|-----|
| **Frontend (App)** | http://localhost:3000 |
| **Backend API** | http://localhost:5000 |
| **Swagger API Docs** | http://localhost:5000/api-docs |
| **AI Service Docs** | http://localhost:8000/docs |

### 4. Login

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@marketai.com | Admin@2024 |
| Analyst | analyst@marketai.com | Admin@2024 |

---

## Local Development (Without Docker)

### Prerequisites

- Node.js 20+
- Python 3.11+
- PostgreSQL 15 running locally
- MongoDB 6 running locally
- Redis 7 running locally

### 1. Backend

```bash
cd backend
npm install

# Create .env.local with your local DB URLs:
cp ../.env .env
# Edit .env: replace 'postgres', 'mongo', 'redis' hostnames with 'localhost'

# Run migrations manually:
psql -U market_user -d market_analysis -f ../database/migrations/001_init.sql

npm run dev
# Runs on http://localhost:5000
```

### 2. AI Service

```bash
cd ai-service
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

uvicorn main:app --reload --port 8000
# Runs on http://localhost:8000
```

### 3. Frontend

```bash
cd frontend
npm install

# Edit vite.config.js: change proxy target to http://localhost:5000
npm run dev
# Runs on http://localhost:3000
```

---

## Project Structure

```
market-analysis/
├── docker-compose.yml
├── .env
├── database/
│   └── migrations/
│       └── 001_init.sql          # Full PostgreSQL schema + seed data
│
├── backend/                       # Node.js Express API
│   ├── Dockerfile
│   ├── package.json
│   └── src/
│       ├── server.js              # Entry point
│       ├── app.js                 # Express config + middleware
│       ├── config/
│       │   ├── database.js        # PostgreSQL pool
│       │   ├── mongodb.js         # Mongoose connection
│       │   ├── redis.js           # Redis client
│       │   └── swagger.js         # OpenAPI spec
│       ├── middleware/
│       │   ├── auth.middleware.js # JWT verify + RBAC
│       │   └── audit.middleware.js
│       ├── controllers/
│       │   ├── auth.controller.js      # Login, register, refresh, logout
│       │   ├── campaign.controller.js  # Campaign CRUD
│       │   ├── data.controller.js      # File upload, social import, events
│       │   ├── analytics.controller.js # AI analysis orchestration
│       │   ├── dashboard.controller.js # KPI aggregations
│       │   ├── user.controller.js      # User management
│       │   └── report.controller.js    # Report generation
│       ├── models/
│       │   └── SocialPost.model.js     # MongoDB schema
│       ├── routes/                     # Express routers
│       └── utils/
│           └── logger.js              # Winston logger
│
├── ai-service/                    # Python FastAPI ML service
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py                    # FastAPI app + endpoints
│   └── models/
│       ├── sentiment_model.py     # Lexicon-based + statistical sentiment
│       ├── engagement_model.py    # Engagement analysis + recommendations
│       ├── forecast_model.py      # Holt-Winters time series forecast
│       └── segment_model.py      # K-Means customer segmentation
│
└── frontend/                      # React 18 SPA
    ├── Dockerfile
    ├── package.json
    ├── vite.config.js
    ├── tailwind.config.js
    └── src/
        ├── App.jsx                # Routes
        ├── main.jsx               # Entry point
        ├── index.css              # Tailwind + global styles
        ├── services/
        │   └── api.js             # Axios with JWT auto-refresh
        ├── store/
        │   └── AuthContext.jsx    # Auth state + hooks
        ├── components/
        │   ├── dashboard/
        │   │   └── Layout.jsx     # Sidebar navigation
        │   └── modules/
        │       └── UIComponents.jsx # Shared components
        └── pages/
            ├── LoginPage.jsx
            ├── DashboardPage.jsx      # Executive overview with KPIs
            ├── CampaignsPage.jsx      # Campaign list + create
            ├── CampaignDetail.jsx     # Per-campaign analytics
            ├── DataPage.jsx           # Upload, import, event entry
            ├── AnalyticsPage.jsx      # Full AI analytics suite
            ├── ReportsPage.jsx        # Report generation
            ├── UsersPage.jsx          # User management (admin)
            └── SettingsPage.jsx       # Profile + system info
```

---

## API Reference

Full interactive docs at **http://localhost:5000/api-docs**

### Authentication

```http
POST /api/auth/login
Content-Type: application/json
{ "email": "admin@marketai.com", "password": "Admin@2024" }

# Returns:
{ "data": { "accessToken": "...", "refreshToken": "...", "user": {...} } }
```

All subsequent requests need:
```http
Authorization: Bearer <accessToken>
```

### Key Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/login | Authenticate user |
| GET  | /api/dashboard/summary | Executive dashboard KPIs |
| GET  | /api/campaigns | List campaigns |
| POST | /api/campaigns | Create campaign |
| POST | /api/data/classifieds/upload | Upload CSV/Excel classified ads |
| POST | /api/data/social/import | Import social media data |
| POST | /api/data/events | Create promotional event |
| POST | /api/analytics/sentiment | Run sentiment analysis |
| POST | /api/analytics/forecast | Generate trend forecast |
| POST | /api/analytics/segment | Run customer segmentation |
| GET  | /api/analytics/performance/:id | Campaign performance KPIs |
| POST | /api/reports/generate | Generate report |

### AI Service Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /sentiment | Analyse text sentiment (array of strings) |
| POST | /engagement | Analyse engagement metrics |
| POST | /forecast | Time-series forecast (Holt-Winters) |
| POST | /segment | K-Means customer segmentation |

---

## Using the Platform

### Step 1 – Create a Campaign

Go to **Campaigns → New Campaign**. Fill in name, channel (social_media / classifieds / events / multi), budget, and date range.

### Step 2 – Load Data

Go to **Data** and use one of three tabs:

**Classifieds Upload:** Upload a CSV with columns:
```
publication, category, ad_text, pub_date, impressions, responses, cost
```

**Social Media Import:** Paste JSON metrics (click "Load sample data" to try):
```json
[{ "date": "2025-01-15", "impressions": 45200, "reach": 38100,
   "clicks": 1840, "likes": 920, "engagement_rate": 4.82,
   "spend": 320.50, "conversions": 38 }]
```

**Promotional Events:** Fill in the structured form with event details and outcomes.

### Step 3 – Run AI Analysis

Go to **Analytics**, select your campaign, then click any analysis button:

- **Sentiment Analysis** – classifies ad text and social post content
- **Engagement Analysis** – finds top engagement drivers and gives recommendations  
- **Trend Forecast** – 7 / 30 / 90 day predictions with confidence intervals
- **Customer Segments** – K-Means clustering of customer behaviour
- **Performance KPIs** – aggregate campaign performance scorecard

Or open a specific campaign and use the quick-run buttons at the top.

### Step 4 – View Dashboard

The **Dashboard** shows real-time KPIs, engagement trend charts, sentiment distribution, and channel comparison.

### Step 5 – Generate Reports

Go to **Reports → Generate Report**, select a campaign and report type. Download the JSON output.

---

## Demo Data Script

To quickly populate the system with demo data, run:

```bash
# With Docker running:
docker-compose exec backend node src/utils/seed.js

# Or locally:
cd backend && node src/utils/seed.js
```

---

## Stopping the Services

```bash
# Stop (keeps data):
docker-compose stop

# Stop and remove containers (keeps volumes/data):
docker-compose down

# Stop and DELETE all data:
docker-compose down -v
```

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Port already in use | Change port in docker-compose.yml and .env |
| Backend can't connect to DB | Wait 15s for postgres to be ready, then `docker-compose restart backend` |
| "Cannot find module" in backend | Run `docker-compose exec backend npm install` |
| AI service not responding | Check `docker-compose logs ai-service` |
| Frontend shows blank | Check `docker-compose logs frontend` for build errors |
| Login fails | Ensure migration ran: `docker-compose logs postgres` should show "database system is ready" |

---

## Default Credentials

```
Admin:   admin@marketai.com   / Admin@2024
Analyst: analyst@marketai.com / Admin@2024
```

> **Security Note:** Change JWT_SECRET and JWT_REFRESH_SECRET in .env before any production deployment.
