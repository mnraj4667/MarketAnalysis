import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  // Docker: set VITE_API_TARGET=http://backend:5000 via docker-compose
  // Local:  defaults to http://localhost:5000
  const apiTarget = env.VITE_API_TARGET || 'http://localhost:5000'

  return {
    plugins: [react()],
    server: {
      host:  '0.0.0.0',
      port:  3000,
      proxy: {
        '/api': {
          target:       apiTarget,
          changeOrigin: true,
        }
      }
    },
    build: {
      outDir:    'dist',
      sourcemap: false,
      chunkSizeWarningLimit: 1000,
    }
  }
})
