import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider, useAuth } from './store/AuthContext'

import Layout        from './components/dashboard/Layout'
import LoginPage     from './pages/LoginPage'
import DashboardPage from './pages/DashboardPage'
import CampaignsPage from './pages/CampaignsPage'
import CampaignDetail from './pages/CampaignDetail'
import DataPage      from './pages/DataPage'
import AnalyticsPage from './pages/AnalyticsPage'
import ReportsPage   from './pages/ReportsPage'
import UsersPage     from './pages/UsersPage'
import SettingsPage  from './pages/SettingsPage'

function PrivateRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-10 w-10 border-4 border-brand-700 border-t-transparent"/>
    </div>
  )
  return user ? children : <Navigate to="/login" replace />
}

function AppRoutes() {
  const { user } = useAuth()
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <LoginPage />} />
      <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
        <Route index            element={<DashboardPage />} />
        <Route path="campaigns" element={<CampaignsPage />} />
        <Route path="campaigns/:id" element={<CampaignDetail />} />
        <Route path="data"      element={<DataPage />} />
        <Route path="analytics" element={<AnalyticsPage />} />
        <Route path="reports"   element={<ReportsPage />} />
        <Route path="users"     element={<UsersPage />} />
        <Route path="settings"  element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppRoutes />
      <Toaster position="top-right" toastOptions={{ duration: 3500 }} />
    </AuthProvider>
  )
}
