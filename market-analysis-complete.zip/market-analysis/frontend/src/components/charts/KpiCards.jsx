import { TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { fmtNumber, fmtPercent, fmtCurrency } from '../../utils/helpers'

// Pure SVG sparkline – no extra package
function Sparkline({ data = [], color = '#2E75B6', height = 32, width = 80 }) {
  if (!data.length) return null
  const min = Math.min(...data)
  const max = Math.max(...data)
  const range = max - min || 1
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width
    const y = height - ((v - min) / range) * (height - 4) - 2
    return `${x},${y}`
  }).join(' ')
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/** Single KPI card with optional sparkline */
export function KpiCard({ label, value, previous, format = 'number', sparkData = [], color = 'blue', icon: Icon }) {
  const colorMap = {
    blue:   { bg: 'bg-blue-50',   text: 'text-blue-700',   line: '#1F4E79' },
    green:  { bg: 'bg-green-50',  text: 'text-green-700',  line: '#375623' },
    orange: { bg: 'bg-orange-50', text: 'text-orange-700', line: '#C55A11' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-700', line: '#7030A0' },
    teal:   { bg: 'bg-teal-50',   text: 'text-teal-700',   line: '#0D6E6E' },
  }
  const c = colorMap[color] || colorMap.blue

  function fmt(v) {
    if (v == null) return '—'
    if (format === 'percent')  return fmtPercent(v)
    if (format === 'currency') return fmtCurrency(v)
    if (format === 'multiple') return parseFloat(v).toFixed(2) + 'x'
    return fmtNumber(v)
  }

  let changePct = null
  let direction = 'flat'
  if (value != null && previous != null && previous !== 0) {
    changePct = ((value - previous) / Math.abs(previous)) * 100
    direction = changePct > 0.5 ? 'up' : changePct < -0.5 ? 'down' : 'flat'
  }

  return (
    <div className="card flex flex-col gap-2 min-w-0">
      <div className="flex items-center justify-between">
        <span className="stat-label">{label}</span>
        {Icon && (
          <span className={`w-7 h-7 rounded-lg flex items-center justify-center ${c.bg} ${c.text}`}>
            <Icon size={14} />
          </span>
        )}
      </div>

      <span className="text-2xl font-bold text-gray-900 leading-tight">{fmt(value)}</span>

      <div className="flex items-center justify-between gap-2">
        {changePct != null ? (
          <span className={`flex items-center gap-0.5 text-xs font-medium
            ${direction === 'up' ? 'text-green-600' : direction === 'down' ? 'text-red-500' : 'text-gray-400'}`}>
            {direction === 'up'   && <TrendingUp   size={12} />}
            {direction === 'down' && <TrendingDown  size={12} />}
            {direction === 'flat' && <Minus         size={12} />}
            {Math.abs(changePct).toFixed(1)}%
          </span>
        ) : (
          <span className="text-xs text-gray-400">No comparison</span>
        )}

        {sparkData.length > 2 && (
          <div className="w-20 h-8 flex-shrink-0">
            <Sparkline data={sparkData} color={c.line} />
          </div>
        )}
      </div>
    </div>
  )
}

/** Grid of KPI cards */
export function KpiGrid({ kpis = [], cols = 4 }) {
  const gridCols = {
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-3',
    4: 'grid-cols-2 md:grid-cols-4',
  }
  return (
    <div className={`grid ${gridCols[cols] || gridCols[4]} gap-4`}>
      {kpis.map((k, i) => <KpiCard key={i} {...k} />)}
    </div>
  )
}
