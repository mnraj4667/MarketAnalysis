import {
  BarChart, Bar, RadarChart, Radar, PolarGrid, PolarAngleAxis,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell
} from 'recharts'
import { channelColor, fmtNumber, fmtCurrency, fmtPercent } from '../../utils/helpers'

const METRIC_OPTIONS = [
  { key: 'impressions',   label: 'Impressions' },
  { key: 'reach',         label: 'Reach' },
  { key: 'clicks',        label: 'Clicks' },
  { key: 'conversions',   label: 'Conversions' },
  { key: 'engagement_rate', label: 'Engagement Rate' },
]

/** Bar chart comparing metrics across social platforms */
export function PlatformBarChart({ data = [], metric = 'impressions', height = 240 }) {
  const formatted = data.map(d => ({
    name:  (d.platform || d.name || '').replace(/_/g, ' '),
    value: parseFloat(d[metric]) || 0,
    color: channelColor(d.platform || d.name),
  }))

  function fmtVal(v) {
    if (metric === 'engagement_rate') return fmtPercent(v)
    if (metric === 'spend')           return fmtCurrency(v)
    return fmtNumber(v)
  }

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={formatted} barSize={38}>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey="name" tick={{ fontSize: 11 }} />
        <YAxis tick={{ fontSize: 11 }} tickFormatter={fmtVal} width={60} />
        <Tooltip formatter={(v) => [fmtVal(v), metric.replace(/_/g, ' ')]} />
        <Bar dataKey="value" name={metric.replace(/_/g, ' ')} radius={[4, 4, 0, 0]}>
          {formatted.map((d, i) => <Cell key={i} fill={d.color} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}

/** Radar chart for multi-dimensional channel comparison */
export function ChannelRadarChart({ data = [], height = 280 }) {
  if (!data.length) return null
  return (
    <ResponsiveContainer width="100%" height={height}>
      <RadarChart data={data}>
        <PolarGrid />
        <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10 }} />
        {['social_media', 'classifieds', 'events'].map((ch, i) => (
          <Radar key={ch} name={ch.replace('_', ' ')} dataKey={ch}
            stroke={['#1F4E79', '#2E75B6', '#375623'][i]}
            fill={['#1F4E79', '#2E75B6', '#375623'][i]}
            fillOpacity={0.15} />
        ))}
        <Legend formatter={v => v.replace('_', ' ')} />
        <Tooltip />
      </RadarChart>
    </ResponsiveContainer>
  )
}

/** Summary metrics table across channels */
export function ChannelSummaryTable({ social = [], events = {}, classifieds = {} }) {
  const rows = [
    { label: 'Channel',       social: 'Social Media', events: 'Events',           classifieds: 'Classifieds' },
    { label: 'Total Reach',   social: fmtNumber(social.reduce((a,b) => a+(+b.reach||0), 0)), events: fmtNumber(events.reach), classifieds: fmtNumber(classifieds.impressions) },
    { label: 'Conversions',   social: fmtNumber(social.reduce((a,b) => a+(+b.conversions||0), 0)), events: fmtNumber(events.conversions), classifieds: fmtNumber(classifieds.responses) },
    { label: 'Total Spend',   social: fmtCurrency(social.reduce((a,b) => a+(+b.spend||0), 0)), events: fmtCurrency(events.spend), classifieds: fmtCurrency(classifieds.spend) },
    { label: 'Avg Engagement',social: fmtPercent(social.reduce((a,b,_,arr) => a+(+b.engagement_rate||0)/arr.length, 0)), events: '—', classifieds: '—' },
  ]

  return (
    <div className="overflow-x-auto">
      <table className="table-auto w-full">
        <thead>
          <tr>
            <th className="w-36">Metric</th>
            <th>Social Media</th>
            <th>Events</th>
            <th>Classifieds</th>
          </tr>
        </thead>
        <tbody>
          {rows.slice(1).map(r => (
            <tr key={r.label}>
              <td className="font-medium text-gray-600">{r.label}</td>
              <td>{r.social}</td>
              <td>{r.events}</td>
              <td>{r.classifieds}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
