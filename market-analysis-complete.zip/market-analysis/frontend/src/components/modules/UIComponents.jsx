// Shared small components
import { Loader2 } from 'lucide-react'

export function Spinner({ size = 20, className = '' }) {
  return <Loader2 size={size} className={`animate-spin text-brand-700 ${className}`} />
}

export function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="flex items-start justify-between mb-6 gap-4">
      <div>
        <h1 className="text-xl font-bold text-gray-900">{title}</h1>
        {subtitle && <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 flex-shrink-0">{actions}</div>}
    </div>
  )
}

export function StatCard({ label, value, change, changeType = 'up', icon: Icon, color = 'blue' }) {
  const colors = {
    blue:   'bg-blue-50  text-blue-700',
    green:  'bg-green-50 text-green-700',
    orange: 'bg-orange-50 text-orange-700',
    purple: 'bg-purple-50 text-purple-700',
    teal:   'bg-teal-50  text-teal-700',
  }
  return (
    <div className="stat-card">
      <div className="flex items-center justify-between">
        <span className="stat-label">{label}</span>
        {Icon && (
          <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${colors[color] || colors.blue}`}>
            <Icon size={16} />
          </span>
        )}
      </div>
      <span className="stat-value">{value ?? '—'}</span>
      {change !== undefined && (
        <span className={changeType === 'up' ? 'stat-change-up' : 'stat-change-down'}>
          {changeType === 'up' ? '▲' : '▼'} {change}
        </span>
      )}
    </div>
  )
}

export function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {Icon && <Icon size={40} className="text-gray-300 mb-3" />}
      <h3 className="text-sm font-semibold text-gray-600">{title}</h3>
      {description && <p className="text-xs text-gray-400 mt-1 max-w-xs">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}

export function Modal({ open, onClose, title, children, footer }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200">
          <h2 className="font-semibold text-gray-900">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-lg leading-none">✕</button>
        </div>
        <div className="px-5 py-4">{children}</div>
        {footer && <div className="px-5 py-4 border-t border-gray-100 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  )
}

export function StatusBadge({ status }) {
  const map = {
    active:    'badge-green',
    completed: 'badge-blue',
    paused:    'badge-orange',
    draft:     'badge-gray',
    pending:   'badge-orange',
    failed:    'badge-red',
  }
  return <span className={map[status] || 'badge-gray'}>{status}</span>
}

export function SectionTitle({ children }) {
  return <h2 className="text-base font-semibold text-gray-800 mb-4">{children}</h2>
}

export function FormField({ label, children, hint }) {
  return (
    <div className="mb-4">
      <label className="label">{label}</label>
      {children}
      {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
    </div>
  )
}
