// ── Number formatters ─────────────────────────────────────────
export function fmtNumber(n) {
  if (n == null || isNaN(parseFloat(n))) return '—'
  const v = parseFloat(n)
  if (v >= 1_000_000) return (v / 1_000_000).toFixed(1) + 'M'
  if (v >= 1_000)     return (v / 1_000).toFixed(1) + 'K'
  return v.toLocaleString('en-US')
}

export function fmtCurrency(n, decimals = 0) {
  if (n == null || isNaN(parseFloat(n))) return '—'
  return '$' + parseFloat(n).toLocaleString('en-US', { maximumFractionDigits: decimals })
}

export function fmtPercent(n, decimals = 2) {
  if (n == null || isNaN(parseFloat(n))) return '—'
  return parseFloat(n).toFixed(decimals) + '%'
}

export function fmtMultiple(n) {
  if (n == null || isNaN(parseFloat(n))) return '—'
  return parseFloat(n).toFixed(2) + 'x'
}

// ── Date helpers ──────────────────────────────────────────────
export function fmtDate(d) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
}

export function fmtDateTime(d) {
  if (!d) return '—'
  return new Date(d).toLocaleString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit'
  })
}

export function daysAgo(d) {
  if (!d) return '—'
  const diff = Math.floor((Date.now() - new Date(d)) / 86400000)
  if (diff === 0) return 'Today'
  if (diff === 1) return 'Yesterday'
  if (diff < 30)  return `${diff} days ago`
  if (diff < 365) return `${Math.floor(diff / 30)} months ago`
  return `${Math.floor(diff / 365)} years ago`
}

// ── Channel helpers ───────────────────────────────────────────
export const CHANNEL_COLORS = {
  facebook:   '#1877F2',
  instagram:  '#E4405F',
  twitter:    '#1DA1F2',
  linkedin:   '#0A66C2',
  youtube:    '#FF0000',
  classifieds:'#2E75B6',
  events:     '#375623',
  multi:      '#7030A0',
}

export function channelColor(name) {
  return CHANNEL_COLORS[(name || '').toLowerCase()] || '#595959'
}

export function channelLabel(name) {
  if (!name) return '—'
  return name.charAt(0).toUpperCase() + name.slice(1).replace(/_/g, ' ')
}

// ── Status helpers ────────────────────────────────────────────
export const STATUS_CLASS = {
  active:    'badge-green',
  completed: 'badge-blue',
  paused:    'badge-orange',
  draft:     'badge-gray',
  pending:   'badge-orange',
  failed:    'badge-red',
  running:   'badge-blue',
}

export function statusClass(s) {
  return STATUS_CLASS[s] || 'badge-gray'
}

// ── Sentiment helpers ─────────────────────────────────────────
export const SENTIMENT_COLORS = {
  positive: '#375623',
  neutral:  '#94a3b8',
  negative: '#C55A11',
}

export function sentimentColor(label) {
  return SENTIMENT_COLORS[label] || '#94a3b8'
}

// ── Chart palette ─────────────────────────────────────────────
export const CHART_COLORS = [
  '#1F4E79', '#2E75B6', '#375623', '#7030A0',
  '#C55A11', '#595959', '#0D6E6E', '#B8860B',
]

// ── API error message extractor ───────────────────────────────
export function apiError(err, fallback = 'An error occurred') {
  return err?.response?.data?.error || err?.message || fallback
}

// ── Truncate string ───────────────────────────────────────────
export function truncate(str, max = 40) {
  if (!str) return ''
  return str.length > max ? str.slice(0, max) + '…' : str
}

// ── Build query string from object ───────────────────────────
export function toQuery(params) {
  const q = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
  return q ? `?${q}` : ''
}
