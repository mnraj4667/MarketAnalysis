import { useState, useEffect, useCallback } from 'react'
import api from '../services/api'
import { apiError } from '../utils/helpers'
import toast from 'react-hot-toast'

// ── Generic data-fetch hook ───────────────────────────────────
export function useFetch(url, deps = []) {
  const [data,    setData]    = useState(null)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState(null)

  const load = useCallback(async () => {
    if (!url) return
    setLoading(true)
    try {
      const res = await api.get(url)
      setData(res.data.data)
      setError(null)
    } catch (err) {
      setError(apiError(err))
    } finally {
      setLoading(false)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, ...deps])

  useEffect(() => { load() }, [load])
  return { data, loading, error, reload: load }
}

// ── Campaigns hook ────────────────────────────────────────────
export function useCampaigns(params = {}) {
  const [campaigns, setCampaigns] = useState([])
  const [meta,      setMeta]      = useState({})
  const [loading,   setLoading]   = useState(true)

  async function load(overrides = {}) {
    setLoading(true)
    try {
      const q = new URLSearchParams({ limit: 50, ...params, ...overrides }).toString()
      const { data } = await api.get(`/campaigns?${q}`)
      setCampaigns(data.data)
      setMeta(data.meta || {})
    } catch (err) {
      toast.error(apiError(err, 'Failed to load campaigns'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])  // eslint-disable-line

  async function create(body) {
    const { data } = await api.post('/campaigns', body)
    await load()
    return data.data
  }

  async function update(id, body) {
    const { data } = await api.put(`/campaigns/${id}`, body)
    await load()
    return data.data
  }

  async function remove(id) {
    await api.delete(`/campaigns/${id}`)
    await load()
  }

  return { campaigns, meta, loading, reload: load, create, update, remove }
}

// ── Dashboard summary hook ────────────────────────────────────
export function useDashboard() {
  const [summary,  setSummary]  = useState(null)
  const [channels, setChannels] = useState(null)
  const [trend,    setTrend]    = useState([])
  const [loading,  setLoading]  = useState(true)

  async function load() {
    setLoading(true)
    try {
      const [s, c, t] = await Promise.all([
        api.get('/dashboard/summary'),
        api.get('/dashboard/channel-comparison'),
        api.get('/dashboard/trend?metric=engagement_rate&days=30'),
      ])
      setSummary(s.data.data)
      setChannels(c.data.data)
      // Group trend by date
      const byDate = {}
      t.data.data.forEach(r => {
        if (!byDate[r.date]) byDate[r.date] = { date: r.date }
        byDate[r.date][r.platform || 'all'] = parseFloat(r.value || 0)
      })
      setTrend(Object.values(byDate).slice(-30))
    } catch (err) {
      toast.error(apiError(err, 'Failed to load dashboard'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])
  return { summary, channels, trend, loading, reload: load }
}

// ── Analytics hook ────────────────────────────────────────────
export function useAnalytics(campaignId) {
  const [sentiment,  setSentiment]  = useState(null)
  const [engagement, setEngagement] = useState(null)
  const [forecast,   setForecast]   = useState(null)
  const [segments,   setSegments]   = useState([])
  const [perf,       setPerf]       = useState(null)
  const [running,    setRunning]    = useState({})

  function spin(key, val) { setRunning(p => ({ ...p, [key]: val })) }

  useEffect(() => {
    if (!campaignId) return
    api.get(`/analytics/sentiment/${campaignId}`).then(r => setSentiment(r.data.data)).catch(() => {})
    api.get(`/analytics/segments/${campaignId}`).then(r => setSegments(r.data.data || [])).catch(() => {})
    api.get(`/analytics/performance/${campaignId}`).then(r => setPerf(r.data.data)).catch(() => {})
  }, [campaignId])

  async function runAnalysis(type, params = {}) {
    spin(type, true)
    try {
      const body = { campaign_id: campaignId, ...params }
      let result
      if      (type === 'sentiment')  { result = await api.post('/analytics/sentiment',  body); setSentiment(result.data.data)  }
      else if (type === 'engagement') { result = await api.post('/analytics/engagement', body); setEngagement(result.data.data) }
      else if (type === 'forecast')   { result = await api.post('/analytics/forecast',   body); setForecast(result.data.data)   }
      else if (type === 'segment')    { result = await api.post('/analytics/segment',    body); setSegments(result.data.data?.segments || []) }
      else if (type === 'performance'){ result = await api.get(`/analytics/performance/${campaignId}`); setPerf(result.data.data) }
      toast.success(`${type.charAt(0).toUpperCase() + type.slice(1)} analysis complete`)
      return result?.data?.data
    } catch (err) {
      toast.error(apiError(err, `${type} analysis failed`))
      throw err
    } finally {
      spin(type, false)
    }
  }

  return { sentiment, engagement, forecast, segments, perf, running, runAnalysis }
}

// ── Paginated list hook ───────────────────────────────────────
export function usePaginatedList(endpoint, pageSize = 20) {
  const [items,   setItems]   = useState([])
  const [page,    setPage]    = useState(1)
  const [total,   setTotal]   = useState(0)
  const [loading, setLoading] = useState(true)

  async function load(p = page) {
    setLoading(true)
    try {
      const { data } = await api.get(`${endpoint}?page=${p}&limit=${pageSize}`)
      setItems(data.data)
      setTotal(data.meta?.total || data.data.length)
      setPage(p)
    } catch (err) {
      toast.error(apiError(err))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(1) }, [endpoint])  // eslint-disable-line

  return {
    items, page, total, loading,
    totalPages: Math.ceil(total / pageSize),
    nextPage:   () => load(page + 1),
    prevPage:   () => load(page - 1),
    goToPage:   (p) => load(p),
    reload:     () => load(page),
  }
}
