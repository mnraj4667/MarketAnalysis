import { createContext, useContext, useState, useEffect } from 'react'
import api from '../services/api'

const AuthCtx = createContext(null)

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('accessToken')
    if (token) {
      api.get('/auth/me')
        .then(r => setUser(r.data.data))
        .catch(() => localStorage.clear())
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  async function login(email, password) {
    const { data } = await api.post('/auth/login', { email, password })
    localStorage.setItem('accessToken',  data.data.accessToken)
    localStorage.setItem('refreshToken', data.data.refreshToken)
    setUser(data.data.user)
    return data.data.user
  }

  async function logout() {
    try { await api.post('/auth/logout') } catch (_) {}
    localStorage.clear()
    setUser(null)
  }

  function can(...perms) {
    if (!user) return false
    if (user.permissions?.includes('*')) return true
    return perms.every(p => user.permissions?.includes(p))
  }

  return (
    <AuthCtx.Provider value={{ user, loading, login, logout, can }}>
      {children}
    </AuthCtx.Provider>
  )
}

export const useAuth = () => useContext(AuthCtx)
