import { useState, useEffect } from 'react'
import { Upload, RefreshCw, CalendarPlus, List } from 'lucide-react'
import api from '../services/api'
import { PageHeader, Modal, FormField, Spinner } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

const TABS = ['Classifieds Upload', 'Social Media Import', 'Promotional Events', 'View Records']

export default function DataPage() {
  const [tab, setTab]               = useState(0)
  const [campaigns, setCampaigns]   = useState([])
  const [uploading, setUploading]   = useState(false)
  const [importing, setImporting]   = useState(false)
  const [saving, setSaving]         = useState(false)
  const [file, setFile]             = useState(null)
  const [uploadCampaign, setUploadCampaign] = useState('')
  const [uploadResult, setUploadResult]     = useState(null)
  const [events, setEvents]         = useState([])
  const [classifieds, setClassifieds] = useState([])

  // Social import form
  const [socialForm, setSocialForm] = useState({
    campaign_id: '', platform: 'facebook',
    posts: '', metrics: ''
  })

  // Event form
  const [eventForm, setEventForm] = useState({
    campaign_id: '', event_name: '', event_type: 'product_launch',
    start_date: '', end_date: '', location: '', budget: '',
    actual_reach: '', estimated_reach: '', leads_generated: '',
    conversions: '', revenue: '', satisfaction_score: '', notes: ''
  })

  useEffect(() => {
    api.get('/campaigns?limit=100').then(r => setCampaigns(r.data.data)).catch(() => {})
    api.get('/data/events').then(r => setEvents(r.data.data)).catch(() => {})
    api.get('/data/classifieds').then(r => setClassifieds(r.data.data)).catch(() => {})
  }, [])

  // ── Upload Classifieds ──────────────────────────────────────
  async function handleUpload(e) {
    e.preventDefault()
    if (!file) return toast.error('Select a file first')
    setUploading(true)
    setUploadResult(null)
    try {
      const fd = new FormData()
      fd.append('file', file)
      if (uploadCampaign) fd.append('campaign_id', uploadCampaign)
      const { data } = await api.post('/data/classifieds/upload', fd, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      setUploadResult(data.data)
      toast.success(`Imported ${data.data.imported} records`)
      api.get('/data/classifieds').then(r => setClassifieds(r.data.data)).catch(() => {})
    } catch (err) {
      toast.error(err.response?.data?.error || 'Upload failed')
    } finally { setUploading(false) }
  }

  // ── Import Social ───────────────────────────────────────────
  async function handleSocialImport(e) {
    e.preventDefault()
    setImporting(true)
    try {
      let posts = [], metrics = []
      try { posts   = socialForm.posts   ? JSON.parse(socialForm.posts)   : [] } catch { toast.error('Invalid JSON in Posts'); setImporting(false); return }
      try { metrics = socialForm.metrics ? JSON.parse(socialForm.metrics) : [] } catch { toast.error('Invalid JSON in Metrics'); setImporting(false); return }
      const { data } = await api.post('/data/social/import', {
        campaign_id: socialForm.campaign_id,
        platform:    socialForm.platform,
        posts, metrics
      })
      toast.success(`Saved ${data.data.savedPosts} posts, ${data.data.savedMetrics} metric rows`)
    } catch (err) {
      toast.error(err.response?.data?.error || 'Import failed')
    } finally { setImporting(false) }
  }

  // ── Create Event ────────────────────────────────────────────
  async function handleCreateEvent(e) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.post('/data/events', eventForm)
      toast.success('Event saved')
      setEventForm({ campaign_id:'', event_name:'', event_type:'product_launch',
        start_date:'', end_date:'', location:'', budget:'', actual_reach:'',
        estimated_reach:'', leads_generated:'', conversions:'', revenue:'',
        satisfaction_score:'', notes:'' })
      const r = await api.get('/data/events')
      setEvents(r.data.data)
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save event')
    } finally { setSaving(false) }
  }

  const EF = ({ label, name, type='text', ...rest }) => (
    <FormField label={label}>
      <input type={type} className="input" value={eventForm[name] || ''}
        onChange={e => setEventForm(p => ({ ...p, [name]: e.target.value }))} {...rest} />
    </FormField>
  )

  const SAMPLE_METRICS = JSON.stringify([
    { date: new Date().toISOString().split('T')[0], impressions: 45200, reach: 38100, clicks: 1840, likes: 920, comments: 145, shares: 67, saves: 201, engagement_rate: 4.82, spend: 320.50, conversions: 38 }
  ], null, 2)

  const SAMPLE_POSTS = JSON.stringify([
    { post_id: 'fb_001', text: 'Exciting new product launch! Check out our amazing offer today – great value guaranteed!', date: new Date().toISOString(), likes: 245, comments: 38, shares: 21, engagement_rate: 5.2, media_type: 'image' }
  ], null, 2)

  return (
    <div>
      <PageHeader title="Data Management" subtitle="Upload and manage marketing data from all channels" />

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 mb-6 w-fit flex-wrap">
        {TABS.map((t, i) => (
          <button key={i} onClick={() => setTab(i)}
            className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
              tab === i ? 'bg-white text-brand-700 shadow-sm' : 'text-gray-600 hover:text-gray-800'
            }`}>{t}</button>
        ))}
      </div>

      {/* ── Tab 0: Upload Classifieds ─────────────────────────── */}
      {tab === 0 && (
        <div className="max-w-2xl">
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-1">Upload Classified Advertisements</h3>
            <p className="text-sm text-gray-500 mb-5">Accepts CSV, Excel (.xlsx/.xls) or XML files. Required columns: publication, category, ad_text, pub_date.</p>
            <form onSubmit={handleUpload} className="space-y-4">
              <FormField label="Campaign (optional)">
                <select className="input" value={uploadCampaign} onChange={e => setUploadCampaign(e.target.value)}>
                  <option value="">— No campaign —</option>
                  {campaigns.map(c => <option key={c.campaign_id} value={c.campaign_id}>{c.name}</option>)}
                </select>
              </FormField>
              <div className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors
                ${file ? 'border-brand-500 bg-blue-50' : 'border-gray-300 hover:border-brand-500'}`}>
                <Upload size={28} className="mx-auto text-gray-400 mb-2" />
                {file ? (
                  <p className="text-sm font-medium text-brand-700">{file.name}</p>
                ) : (
                  <p className="text-sm text-gray-500">Drop file here or click to browse</p>
                )}
                <input type="file" className="mt-3 text-xs text-gray-500 cursor-pointer mx-auto block"
                  accept=".csv,.xlsx,.xls,.xml" onChange={e => setFile(e.target.files[0])} />
              </div>
              <button type="submit" className="btn-primary w-full justify-center" disabled={uploading || !file}>
                {uploading ? <><Spinner size={14}/> Uploading…</> : <><Upload size={14}/> Upload File</>}
              </button>
            </form>
            {uploadResult && (
              <div className="mt-4 p-4 bg-green-50 rounded-lg text-sm">
                <p className="font-semibold text-green-800 mb-1">Upload complete</p>
                <p className="text-green-700">✓ Imported: {uploadResult.imported} &nbsp;|&nbsp; ✗ Failed: {uploadResult.failed} &nbsp;|&nbsp; Total: {uploadResult.total}</p>
                {uploadResult.errors?.length > 0 && (
                  <details className="mt-2"><summary className="cursor-pointer text-xs text-green-600">Show errors</summary>
                    <pre className="text-xs mt-1 text-red-600">{JSON.stringify(uploadResult.errors, null, 2)}</pre>
                  </details>
                )}
              </div>
            )}
          </div>

          <div className="mt-4 card bg-blue-50 border-blue-200">
            <p className="text-xs font-semibold text-blue-800 mb-2">Sample CSV format</p>
            <pre className="text-xs text-blue-700 overflow-x-auto">
{`publication,category,ad_text,pub_date,impressions,responses,cost
Daily Herald,Real Estate,"3-bed house for sale – great value in prime area",2024-01-15,12400,38,245.00
City Times,Automotive,"2022 Toyota Camry – low mileage excellent condition",2024-01-15,8900,22,180.00`}
            </pre>
          </div>
        </div>
      )}

      {/* ── Tab 1: Social Media Import ───────────────────────── */}
      {tab === 1 && (
        <div className="max-w-2xl">
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-1">Import Social Media Analytics</h3>
            <p className="text-sm text-gray-500 mb-5">Paste JSON data from your social media platform API exports.</p>
            <form onSubmit={handleSocialImport} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField label="Campaign">
                  <select className="input" value={socialForm.campaign_id}
                    onChange={e => setSocialForm(p => ({ ...p, campaign_id: e.target.value }))}>
                    <option value="">— Select campaign —</option>
                    {campaigns.map(c => <option key={c.campaign_id} value={c.campaign_id}>{c.name}</option>)}
                  </select>
                </FormField>
                <FormField label="Platform">
                  <select className="input" value={socialForm.platform}
                    onChange={e => setSocialForm(p => ({ ...p, platform: e.target.value }))}>
                    {['facebook','instagram','twitter','linkedin','youtube'].map(p => (
                      <option key={p} value={p}>{p.charAt(0).toUpperCase()+p.slice(1)}</option>
                    ))}
                  </select>
                </FormField>
              </div>
              <FormField label="Daily Metrics (JSON array)" hint="Paste sample below to try">
                <textarea className="input font-mono text-xs" rows={6} value={socialForm.metrics}
                  onChange={e => setSocialForm(p => ({ ...p, metrics: e.target.value }))}
                  placeholder={SAMPLE_METRICS} />
              </FormField>
              <FormField label="Post Content (JSON array, optional)">
                <textarea className="input font-mono text-xs" rows={5} value={socialForm.posts}
                  onChange={e => setSocialForm(p => ({ ...p, posts: e.target.value }))}
                  placeholder={SAMPLE_POSTS} />
              </FormField>
              <div className="flex gap-2">
                <button type="button" className="btn-secondary text-xs"
                  onClick={() => setSocialForm(p => ({ ...p, metrics: SAMPLE_METRICS, posts: SAMPLE_POSTS }))}>
                  Load sample data
                </button>
                <button type="submit" className="btn-primary" disabled={importing}>
                  {importing ? <><Spinner size={14}/> Importing…</> : <><RefreshCw size={14}/> Import</>}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ── Tab 2: Promotional Events ────────────────────────── */}
      {tab === 2 && (
        <div className="max-w-2xl">
          <div className="card">
            <h3 className="font-semibold text-gray-800 mb-1">Enter Promotional Event Data</h3>
            <p className="text-sm text-gray-500 mb-5">Record event parameters and outcome metrics.</p>
            <form onSubmit={handleCreateEvent}>
              <div className="grid grid-cols-2 gap-3">
                <FormField label="Campaign" hint="">
                  <select className="input" value={eventForm.campaign_id}
                    onChange={e => setEventForm(p => ({ ...p, campaign_id: e.target.value }))}>
                    <option value="">— Select campaign —</option>
                    {campaigns.map(c => <option key={c.campaign_id} value={c.campaign_id}>{c.name}</option>)}
                  </select>
                </FormField>
                <EF label="Event name *" name="event_name" required placeholder="e.g. Summer Launch 2025" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <FormField label="Event type">
                  <select className="input" value={eventForm.event_type}
                    onChange={e => setEventForm(p => ({ ...p, event_type: e.target.value }))}>
                    {['product_launch','trade_show','seasonal_campaign','loyalty_program','webinar','conference'].map(t => (
                      <option key={t} value={t}>{t.replace(/_/g,' ')}</option>
                    ))}
                  </select>
                </FormField>
                <EF label="Location" name="location" placeholder="City or Online" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <EF label="Start date" name="start_date" type="date" />
                <EF label="End date"   name="end_date"   type="date" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <EF label="Budget ($)"    name="budget"           type="number" />
                <EF label="Est. Reach"    name="estimated_reach"  type="number" />
                <EF label="Actual Reach"  name="actual_reach"     type="number" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <EF label="Leads"         name="leads_generated"  type="number" />
                <EF label="Conversions"   name="conversions"      type="number" />
                <EF label="Revenue ($)"   name="revenue"          type="number" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <EF label="Satisfaction (0-5)" name="satisfaction_score" type="number" min="0" max="5" step="0.1" />
                <EF label="NPS Score"          name="nps_score"          type="number" min="-100" max="100" />
              </div>
              <FormField label="Notes">
                <textarea className="input" rows={2} value={eventForm.notes}
                  onChange={e => setEventForm(p => ({ ...p, notes: e.target.value }))} />
              </FormField>
              <button type="submit" className="btn-primary w-full justify-center" disabled={saving}>
                {saving ? <><Spinner size={14}/> Saving…</> : <><CalendarPlus size={14}/> Save Event</>}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ── Tab 3: View Records ──────────────────────────────── */}
      {tab === 3 && (
        <div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Events table */}
            <div className="card p-0 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-100">
                <h3 className="font-semibold text-sm text-gray-800">Promotional Events ({events.length})</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="table-auto w-full">
                  <thead><tr><th>Name</th><th>Type</th><th>Reach</th><th>Conv.</th></tr></thead>
                  <tbody>
                    {events.length === 0 ? (
                      <tr><td colSpan={4} className="text-center text-gray-400 py-6 text-sm">No events yet</td></tr>
                    ) : events.slice(0,10).map(e => (
                      <tr key={e.event_id}>
                        <td className="max-w-[140px] truncate">{e.event_name}</td>
                        <td className="capitalize text-xs">{e.event_type?.replace(/_/g,' ')}</td>
                        <td>{e.actual_reach?.toLocaleString() || '—'}</td>
                        <td>{e.conversions || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Classifieds table */}
            <div className="card p-0 overflow-hidden">
              <div className="px-4 py-3 border-b border-gray-100">
                <h3 className="font-semibold text-sm text-gray-800">Classified Ads ({classifieds.length})</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="table-auto w-full">
                  <thead><tr><th>Publication</th><th>Category</th><th>Impressions</th><th>Responses</th></tr></thead>
                  <tbody>
                    {classifieds.length === 0 ? (
                      <tr><td colSpan={4} className="text-center text-gray-400 py-6 text-sm">No classified ads yet</td></tr>
                    ) : classifieds.slice(0,10).map(a => (
                      <tr key={a.ad_id}>
                        <td className="max-w-[120px] truncate">{a.publication || '—'}</td>
                        <td>{a.category || '—'}</td>
                        <td>{a.impressions?.toLocaleString() || '0'}</td>
                        <td>{a.responses || '0'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
