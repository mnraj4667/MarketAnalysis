import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area
} from 'recharts'
import { ArrowLeft, Play, TrendingUp, Users, BarChart2, RefreshCw } from 'lucide-react'
import api from '../services/api'
import { Spinner, StatCard, SectionTitle, StatusBadge } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

const COLORS = ['#1F4E79','#2E75B6','#375623','#7030A0','#C55A11','#595959']
const fmt = (n, t = 'number') => {
  if (n == null || isNaN(parseFloat(n))) return '—'
  const v = parseFloat(n)
  if (t === 'pct')  return v.toFixed(2) + '%'
  if (t === 'usd')  return '$' + v.toLocaleString('en-US', { maximumFractionDigits: 0 })
  if (v >= 1_000_000) return (v/1_000_000).toFixed(1) + 'M'
  if (v >= 1_000)     return (v/1_000).toFixed(1)     + 'K'
  return v.toLocaleString()
}

export default function CampaignDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [campaign,   setCampaign]   = useState(null)
  const [perf,       setPerf]       = useState(null)
  const [sentiment,  setSentiment]  = useState(null)
  const [segments,   setSegments]   = useState([])
  const [forecast,   setForecast]   = useState(null)
  const [loading,    setLoading]    = useState(true)
  const [running,    setRunning]    = useState({})

  async function load() {
    setLoading(true)
    try {
      const [c, p] = await Promise.all([
        api.get(`/campaigns/${id}`),
        api.get(`/analytics/performance/${id}`).catch(() => ({ data: { data: null } }))
      ])
      setCampaign(c.data.data)
      setPerf(p.data.data)
      // sentiment / segments (may be empty)
      api.get(`/analytics/sentiment/${id}`).then(r => setSentiment(r.data.data)).catch(() => {})
      api.get(`/analytics/segments/${id}`).then(r => setSegments(r.data.data || [])).catch(() => {})
    } catch { toast.error('Failed to load campaign') }
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [id])

  async function runAI(type) {
    setRunning(p => ({ ...p, [type]: true }))
    try {
      if (type === 'sentiment') {
        const r = await api.post('/analytics/sentiment', { campaign_id: id })
        setSentiment(r.data.data)
        toast.success('Sentiment analysis complete')
      } else if (type === 'forecast') {
        const r = await api.post('/analytics/forecast', { campaign_id: id, horizon_days: 30 })
        setForecast(r.data.data)
        toast.success('Forecast generated')
      } else if (type === 'segment') {
        const r = await api.post('/analytics/segment', { campaign_id: id })
        setSegments(r.data.data.segments || [])
        toast.success('Segmentation complete')
      } else if (type === 'engagement') {
        await api.post('/analytics/engagement', { campaign_id: id })
        toast.success('Engagement analysis complete')
        load()
      }
    } catch (e) {
      toast.error(e.response?.data?.error || `${type} failed`)
    } finally {
      setRunning(p => ({ ...p, [type]: false }))
    }
  }

  if (loading) return <div className="flex justify-center py-20"><Spinner size={28} /></div>
  if (!campaign) return <div className="text-center py-20 text-gray-400">Campaign not found</div>

  const kpis = perf?.kpis || {}
  const sm   = perf?.social_metrics || {}
  const em   = perf?.event_metrics  || {}

  const sentSummary = sentiment?.summary || {}
  const sentTotal   = Object.values(sentSummary).reduce((a, b) => a + b, 0)
  const sentPie     = Object.entries(sentSummary).map(([k, v]) => ({ name: k, value: v }))
  const sentColors  = { positive: '#375623', neutral: '#94a3b8', negative: '#C55A11' }

  const forecastData = forecast?.forecast?.forecast || []
  const histData     = (forecast?.historical || []).slice(-30)
  const combinedChart = [
    ...histData.map(d => ({ date: d.date?.slice(5), value: parseFloat(d.value || 0), type: 'historical' })),
    ...forecastData.slice(0, 14).map(d => ({ date: d.date?.slice(5), forecast: parseFloat(d.value || 0), type: 'forecast' }))
  ]

  return (
    <div>
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate('/campaigns')} className="text-gray-400 hover:text-brand-700 transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold text-gray-900">{campaign.name}</h1>
            <StatusBadge status={campaign.status} />
          </div>
          <p className="text-sm text-gray-500 mt-0.5">
            {campaign.channel?.replace('_',' ')} · {campaign.campaign_type || 'campaign'}
            {campaign.start_date && ` · ${new Date(campaign.start_date).toLocaleDateString()} – ${campaign.end_date ? new Date(campaign.end_date).toLocaleDateString() : 'ongoing'}`}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {[
            { type: 'sentiment',  label: 'Sentiment',  icon: BarChart2 },
            { type: 'forecast',   label: 'Forecast',   icon: TrendingUp },
            { type: 'segment',    label: 'Segment',    icon: Users },
            { type: 'engagement', label: 'Engagement', icon: RefreshCw },
          ].map(({ type, label, icon: Icon }) => (
            <button key={type} className="btn-secondary text-xs py-1.5 px-3"
              disabled={running[type]} onClick={() => runAI(type)}>
              {running[type] ? <Spinner size={12} /> : <Play size={12} />}
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Reach"       value={fmt((parseInt(sm.reach)||0)+(parseInt(em.reach)||0))} icon={Users}     color="blue" />
        <StatCard label="Total Conversions" value={fmt(kpis.total_conversions)}                          icon={TrendingUp} color="green" />
        <StatCard label="Avg Engagement"    value={fmt(kpis.avg_engagement,'pct')}                       icon={BarChart2}  color="purple" />
        <StatCard label="ROI"               value={kpis.roi ? kpis.roi.toFixed(2) + 'x' : '—'}          icon={TrendingUp} color="orange" />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {/* Forecast */}
        <div className="card">
          <SectionTitle>Engagement Rate Forecast</SectionTitle>
          {combinedChart.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={combinedChart}>
                <defs>
                  <linearGradient id="gh" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#2E75B6" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#2E75B6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={v => v.toFixed(1) + '%'} />
                <Tooltip formatter={(v, n) => [typeof v === 'number' ? v.toFixed(2)+'%' : v, n]} />
                <Legend />
                <Area type="monotone" dataKey="value"    stroke="#2E75B6" fill="url(#gh)" strokeWidth={2} name="Historical" dot={false} />
                <Line type="monotone" dataKey="forecast" stroke="#C55A11" strokeWidth={2} strokeDasharray="5 3" name="Forecast" dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[220px] text-sm text-gray-400">
              Click "Forecast" to generate predictions
            </div>
          )}
        </div>

        {/* Sentiment */}
        <div className="card">
          <SectionTitle>Sentiment Analysis</SectionTitle>
          {sentPie.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={sentPie} cx="50%" cy="50%" innerRadius={45} outerRadius={75}
                    dataKey="value" label={({ name, percent }) => `${name} ${(percent*100).toFixed(0)}%`}
                    labelLine={false}>
                    {sentPie.map(s => <Cell key={s.name} fill={sentColors[s.name] || '#94a3b8'} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                {sentPie.map(s => (
                  <div key={s.name} className="bg-gray-50 rounded-lg p-2">
                    <p className="text-xs text-gray-500 capitalize">{s.name}</p>
                    <p className="text-lg font-bold" style={{ color: sentColors[s.name] }}>{s.value}</p>
                    <p className="text-xs text-gray-400">{sentTotal > 0 ? ((s.value/sentTotal)*100).toFixed(0) : 0}%</p>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-[220px] text-sm text-gray-400">
              Click "Sentiment" to analyse content
            </div>
          )}
        </div>
      </div>

      {/* Customer Segments */}
      {segments.length > 0 && (
        <div className="card mb-4">
          <SectionTitle>Customer Segments</SectionTitle>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
            {segments.map((seg, i) => (
              <div key={i} className="rounded-lg p-3 text-center border border-gray-100"
                style={{ borderTop: `3px solid ${seg.color || COLORS[i % COLORS.length]}` }}>
                <p className="text-xs font-semibold text-gray-700 leading-tight mb-1">{seg.name}</p>
                <p className="text-xl font-bold" style={{ color: seg.color || COLORS[i % COLORS.length] }}>
                  {seg.percentage}%
                </p>
                <p className="text-xs text-gray-400">{seg.count} members</p>
                <div className="mt-2 text-xs text-gray-500 space-y-0.5">
                  <p>Engagement: {(seg.characteristics?.avg_engagement * 100)?.toFixed(1) || '—'}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Campaign info */}
      <div className="card">
        <SectionTitle>Campaign Details</SectionTitle>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          {[
            ['Budget', campaign.budget ? `$${parseFloat(campaign.budget).toLocaleString()}` : '—'],
            ['Target Segment', campaign.target_segment || '—'],
            ['Channel', (campaign.channel || '—').replace('_', ' ')],
            ['Type', campaign.campaign_type || '—'],
          ].map(([k, v]) => (
            <div key={k}>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">{k}</p>
              <p className="font-semibold text-gray-800 capitalize">{v}</p>
            </div>
          ))}
        </div>
        {campaign.description && (
          <p className="mt-4 text-sm text-gray-600 border-t border-gray-100 pt-4">{campaign.description}</p>
        )}
      </div>
    </div>
  )
}
