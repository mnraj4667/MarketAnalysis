import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, Search, ChevronRight } from 'lucide-react'
import api from '../services/api'
import { PageHeader, Spinner, EmptyState, StatusBadge, Modal, FormField } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

const EMPTY_FORM = {
  name: '', description: '', campaign_type: 'digital',
  channel: 'social_media', start_date: '', end_date: '',
  budget: '', target_segment: '', status: 'active'
}

export default function CampaignsPage() {
  const navigate = useNavigate()
  const [campaigns, setCampaigns] = useState([])
  const [loading, setLoading]     = useState(true)
  const [search, setSearch]       = useState('')
  const [showModal, setShowModal] = useState(false)
  const [form, setForm]           = useState(EMPTY_FORM)
  const [saving, setSaving]       = useState(false)

  async function load() {
    try {
      const { data } = await api.get('/campaigns?limit=50')
      setCampaigns(data.data)
    } catch { toast.error('Failed to load campaigns') }
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  async function handleCreate(e) {
    e.preventDefault()
    setSaving(true)
    try {
      const { data } = await api.post('/campaigns', form)
      toast.success('Campaign created')
      setShowModal(false)
      setForm(EMPTY_FORM)
      navigate(`/campaigns/${data.data.campaign_id}`)
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create campaign')
    } finally { setSaving(false) }
  }

  function Field({ label, name, type = 'text', children, ...rest }) {
    return (
      <FormField label={label}>
        {children || (
          <input type={type} className="input" value={form[name] || ''}
            onChange={e => setForm(p => ({ ...p, [name]: e.target.value }))} {...rest} />
        )}
      </FormField>
    )
  }

  const filtered = campaigns.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.channel || '').toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div>
      <PageHeader title="Campaigns" subtitle={`${campaigns.length} campaigns total`}
        actions={
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={16} /> New Campaign
          </button>
        } />

      {/* Search */}
      <div className="relative mb-4 max-w-sm">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input className="input pl-9" placeholder="Search campaigns…"
          value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size={28} /></div>
      ) : filtered.length === 0 ? (
        <EmptyState title="No campaigns found"
          description="Create your first campaign to get started"
          action={<button className="btn-primary" onClick={() => setShowModal(true)}><Plus size={15}/>New Campaign</button>} />
      ) : (
        <div className="card p-0 overflow-hidden">
          <table className="table-auto w-full">
            <thead>
              <tr>
                <th>Name</th>
                <th>Channel</th>
                <th>Type</th>
                <th>Budget</th>
                <th>Status</th>
                <th>Created</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.campaign_id} className="cursor-pointer"
                  onClick={() => navigate(`/campaigns/${c.campaign_id}`)}>
                  <td className="font-medium text-brand-700 max-w-[200px] truncate">{c.name}</td>
                  <td className="capitalize">{c.channel?.replace('_',' ') || '—'}</td>
                  <td className="capitalize">{c.campaign_type || '—'}</td>
                  <td>{c.budget ? `$${parseFloat(c.budget).toLocaleString()}` : '—'}</td>
                  <td><StatusBadge status={c.status} /></td>
                  <td className="text-gray-400 text-xs">{new Date(c.created_at).toLocaleDateString()}</td>
                  <td><ChevronRight size={16} className="text-gray-300" /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Create Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="New Campaign"
        footer={<>
          <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
          <button className="btn-primary" onClick={handleCreate} disabled={saving}>
            {saving ? 'Creating…' : 'Create Campaign'}
          </button>
        </>}>
        <div className="grid grid-cols-1 gap-0">
          <Field label="Campaign name *" name="name" placeholder="e.g. Summer 2025 Social" required />
          <Field label="Description" name="description">
            <textarea className="input" rows={2} value={form.description}
              onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <FormField label="Channel">
              <select className="input" value={form.channel}
                onChange={e => setForm(p => ({ ...p, channel: e.target.value }))}>
                <option value="social_media">Social Media</option>
                <option value="classifieds">Classifieds</option>
                <option value="events">Events</option>
                <option value="multi">Multi-channel</option>
              </select>
            </FormField>
            <FormField label="Status">
              <select className="input" value={form.status}
                onChange={e => setForm(p => ({ ...p, status: e.target.value }))}>
                <option value="active">Active</option>
                <option value="draft">Draft</option>
                <option value="paused">Paused</option>
              </select>
            </FormField>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start date" name="start_date" type="date" />
            <Field label="End date"   name="end_date"   type="date" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Budget ($)" name="budget" type="number" placeholder="0.00" />
            <Field label="Target segment" name="target_segment" placeholder="e.g. 18–35 urban" />
          </div>
        </div>
      </Modal>
    </div>
  )
}
