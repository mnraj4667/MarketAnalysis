import { useEffect, useState } from 'react'
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, RadarChart,
  Radar, PolarGrid, PolarAngleAxis, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, AreaChart, Area
} from 'recharts'
import { Play, TrendingUp, Users, BarChart2, Zap, ChevronDown } from 'lucide-react'
import api from '../services/api'
import { PageHeader, Spinner, StatCard, SectionTitle, FormField } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

const COLORS = ['#1F4E79','#2E75B6','#375623','#7030A0','#C55A11','#595959']

export default function AnalyticsPage() {
  const [campaigns, setCampaigns]   = useState([])
  const [selCamp,   setSelCamp]     = useState('')
  const [loading,   setLoading]     = useState({})
  const [sentiment, setSentiment]   = useState(null)
  const [engagement,setEngagement]  = useState(null)
  const [forecast,  setForecast]    = useState(null)
  const [segments,  setSegments]    = useState([])
  const [perf,      setPerf]        = useState(null)
  const [horizon,   setHorizon]     = useState(30)

  useEffect(() => {
    api.get('/campaigns?limit=100').then(r => {
      setCampaigns(r.data.data)
      if (r.data.data.length > 0) setSelCamp(r.data.data[0].campaign_id)
    }).catch(() => {})
  }, [])

  function spin(key, val) { setLoading(p => ({ ...p, [key]: val })) }

  async function run(type) {
    if (!selCamp) return toast.error('Select a campaign first')
    spin(type, true)
    try {
      if (type === 'sentiment') {
        const r = await api.post('/analytics/sentiment', { campaign_id: selCamp })
        setSentiment(r.data.data)
        toast.success('Sentiment analysis complete')
      } else if (type === 'engagement') {
        const r = await api.post('/analytics/engagement', { campaign_id: selCamp })
        setEngagement(r.data.data)
        toast.success('Engagement analysis complete')
      } else if (type === 'forecast') {
        const r = await api.post('/analytics/forecast', { campaign_id: selCamp, horizon_days: horizon })
        setForecast(r.data.data)
        toast.success('Forecast generated')
      } else if (type === 'segment') {
        const r = await api.post('/analytics/segment', { campaign_id: selCamp })
        setSegments(r.data.data.segments || [])
        toast.success('Segmentation complete')
      } else if (type === 'performance') {
        const r = await api.get(`/analytics/performance/${selCamp}`)
        setPerf(r.data.data)
        toast.success('Performance loaded')
      }
    } catch (e) {
      toast.error(e.response?.data?.error || `${type} failed`)
    } finally { spin(type, false) }
  }

  // ── Derived chart data ─────────────────────────────────────
  const sentSummary = sentiment?.summary || {}
  const sentTotal   = Object.values(sentSummary).reduce((a, b) => a + b, 0)
  const sentPie     = Object.entries(sentSummary).map(([k, v]) => ({ name: k, value: v }))
  const sentBarData = sentPie.map(s => ({
    name: s.name.charAt(0).toUpperCase() + s.name.slice(1),
    count: s.value,
    pct: sentTotal > 0 ? +((s.value / sentTotal) * 100).toFixed(1) : 0
  }))

  const engPlatforms = engagement?.platform_analysis || []
  const engFactors   = engagement?.top_factors || []
  const radarData    = engFactors.slice(0, 6).map(f => ({
    factor: f.factor.split(' ').slice(0, 3).join(' '),
    importance: +(f.importance * 100).toFixed(1)
  }))

  const histData  = (forecast?.historical || []).slice(-30)
  const fcstData  = forecast?.forecast?.forecast || []
  const fcstUpper = forecast?.forecast?.upper || []
  const fcstLower = forecast?.forecast?.lower || []
  const combinedForecast = [
    ...histData.map((d, i) => ({
      date: d.date?.slice(5) || i,
      historical: +parseFloat(d.value || 0).toFixed(3),
    })),
    ...fcstData.map((d, i) => ({
      date: d.date?.slice(5),
      forecast: +parseFloat(d.value || 0).toFixed(3),
      upper: +parseFloat(fcstUpper[i]?.value || d.value || 0).toFixed(3),
      lower: +parseFloat(fcstLower[i]?.value || d.value || 0).toFixed(3),
    }))
  ]

  const kpis = perf?.kpis || {}
  const sm   = perf?.social_metrics || {}

  function RunBtn({ type, label, icon: Icon, color = 'brand' }) {
    return (
      <button onClick={() => run(type)} disabled={loading[type] || !selCamp}
        className="flex items-center gap-2 px-4 py-3 rounded-xl border border-gray-200 bg-white
                   hover:border-brand-500 hover:shadow-sm transition-all text-sm font-medium
                   text-gray-700 disabled:opacity-50 w-full">
        {loading[type] ? <Spinner size={16} /> : <Icon size={16} className="text-brand-700" />}
        <span className="flex-1 text-left">{loading[type] ? 'Running…' : label}</span>
        <Play size={12} className="text-gray-300" />
      </button>
    )
  }

  return (
    <div>
      <PageHeader title="AI Analytics" subtitle="Run machine learning analyses on your campaign data" />

      {/* Campaign Selector + Controls */}
      <div className="card mb-6">
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex-1 min-w-[200px]">
            <FormField label="Select Campaign">
              <select className="input" value={selCamp} onChange={e => setSelCamp(e.target.value)}>
                <option value="">— Choose a campaign —</option>
                {campaigns.map(c => (
                  <option key={c.campaign_id} value={c.campaign_id}>{c.name}</option>
                ))}
              </select>
            </FormField>
          </div>
          <div className="w-40">
            <FormField label="Forecast horizon (days)">
              <input type="number" className="input" value={horizon} min={7} max={90}
                onChange={e => setHorizon(+e.target.value)} />
            </FormField>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-2">
          <RunBtn type="sentiment"   label="Sentiment Analysis"  icon={BarChart2} />
          <RunBtn type="engagement"  label="Engagement Analysis" icon={Zap} />
          <RunBtn type="forecast"    label="Trend Forecast"      icon={TrendingUp} />
          <RunBtn type="segment"     label="Customer Segments"   icon={Users} />
          <RunBtn type="performance" label="Performance KPIs"    icon={BarChart2} />
        </div>
      </div>

      {/* Performance KPIs */}
      {perf && (
        <div className="mb-6">
          <SectionTitle>Campaign Performance KPIs</SectionTitle>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard label="Total Reach"       value={perf ? ((parseInt(sm.reach)||0)+(parseInt(perf.event_metrics?.reach)||0)).toLocaleString() : '—'} color="blue"   icon={Users} />
            <StatCard label="Total Conversions" value={kpis.total_conversions?.toLocaleString() || '—'}                                                   color="green"  icon={TrendingUp} />
            <StatCard label="Avg Engagement"    value={kpis.avg_engagement ? kpis.avg_engagement.toFixed(2)+'%' : '—'}                                    color="purple" icon={BarChart2} />
            <StatCard label="ROI"               value={kpis.roi ? kpis.roi.toFixed(2)+'x' : '—'}                                                          color="orange" icon={Zap} />
          </div>
        </div>
      )}

      {/* Sentiment Results */}
      {sentPie.length > 0 && (
        <div className="mb-6">
          <SectionTitle>Sentiment Analysis Results</SectionTitle>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card">
              <p className="text-sm font-medium text-gray-600 mb-3">Distribution</p>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={sentBarData} barSize={48}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="left" tick={{ fontSize: 11 }} />
                  <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} tickFormatter={v => v + '%'} />
                  <Tooltip />
                  <Bar yAxisId="left" dataKey="count" name="Count" radius={[4,4,0,0]}>
                    {sentBarData.map((_, i) => <Cell key={i} fill={['#375623','#94a3b8','#C55A11'][i]} />)}
                  </Bar>
                  <Bar yAxisId="right" dataKey="pct" name="%" fill="#BDD7EE" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="card">
              <p className="text-sm font-medium text-gray-600 mb-3">Breakdown</p>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={sentPie} cx="50%" cy="50%" outerRadius={85} dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent*100).toFixed(0)}%`}>
                    {sentPie.map((_, i) => <Cell key={i} fill={['#375623','#94a3b8','#C55A11'][i]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              {sentTotal > 0 && (
                <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                  {sentPie.map((s, i) => (
                    <div key={s.name} className="rounded-lg p-2 bg-gray-50">
                      <p className="text-xs text-gray-500 capitalize">{s.name}</p>
                      <p className="text-xl font-bold" style={{ color: ['#375623','#94a3b8','#C55A11'][i] }}>
                        {((s.value / sentTotal) * 100).toFixed(0)}%
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Engagement Results */}
      {(engPlatforms.length > 0 || engFactors.length > 0) && (
        <div className="mb-6">
          <SectionTitle>Engagement Analysis</SectionTitle>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {engPlatforms.length > 0 && (
              <div className="card">
                <p className="text-sm font-medium text-gray-600 mb-3">Platform Engagement vs Benchmark</p>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={engPlatforms.map(p => ({
                    platform: p.platform,
                    actual: +parseFloat(p.engagement_rate || 0).toFixed(2),
                    benchmark: +parseFloat(p.benchmark || 0).toFixed(2)
                  }))} barSize={28}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis dataKey="platform" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} tickFormatter={v => v + '%'} />
                    <Tooltip formatter={v => v + '%'} />
                    <Legend />
                    <Bar dataKey="actual"    fill="#1F4E79" name="Actual" radius={[4,4,0,0]} />
                    <Bar dataKey="benchmark" fill="#BDD7EE" name="Benchmark" radius={[4,4,0,0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
            {radarData.length > 0 && (
              <div className="card">
                <p className="text-sm font-medium text-gray-600 mb-3">Feature Importance</p>
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="factor" tick={{ fontSize: 10 }} />
                    <Radar name="Importance" dataKey="importance" stroke="#2E75B6"
                      fill="#2E75B6" fillOpacity={0.3} />
                    <Tooltip formatter={v => v + '%'} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
          {engagement?.recommendations?.length > 0 && (
            <div className="card mt-4 bg-blue-50 border-blue-200">
              <p className="text-sm font-semibold text-blue-800 mb-2">AI Recommendations</p>
              <ul className="space-y-1.5">
                {engagement.recommendations.map((r, i) => (
                  <li key={i} className="flex gap-2 text-sm text-blue-700">
                    <span className="text-blue-400 flex-shrink-0 mt-0.5">▸</span>
                    {r}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* Forecast Results */}
      {combinedForecast.length > 0 && (
        <div className="mb-6">
          <SectionTitle>
            Trend Forecast — {forecast?.forecast?.metric || 'Engagement Rate'}
            {forecast?.forecast?.mape !== undefined && (
              <span className="ml-2 text-xs font-normal text-gray-400">MAPE: {forecast.forecast.mape}%</span>
            )}
          </SectionTitle>
          <div className="card">
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={combinedForecast}>
                <defs>
                  <linearGradient id="colorHist" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2E75B6" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#2E75B6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorFcst" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#C55A11" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#C55A11" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={4} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={v => v.toFixed(1) + '%'} />
                <Tooltip formatter={(v, n) => [typeof v === 'number' ? v.toFixed(3) + '%' : v, n]} />
                <Legend />
                <Area type="monotone" dataKey="historical" stroke="#2E75B6" fill="url(#colorHist)"
                  strokeWidth={2} dot={false} name="Historical" connectNulls />
                <Area type="monotone" dataKey="forecast"   stroke="#C55A11" fill="url(#colorFcst)"
                  strokeWidth={2} strokeDasharray="5 3" dot={false} name="Forecast" connectNulls />
                <Line type="monotone" dataKey="upper" stroke="#C55A11" strokeWidth={1}
                  strokeDasharray="2 3" dot={false} name="Upper CI" opacity={0.4} />
                <Line type="monotone" dataKey="lower" stroke="#C55A11" strokeWidth={1}
                  strokeDasharray="2 3" dot={false} name="Lower CI" opacity={0.4} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Segmentation Results */}
      {segments.length > 0 && (
        <div className="mb-6">
          <SectionTitle>Customer Segmentation — {segments.length} Segments</SectionTitle>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="card">
              <p className="text-sm font-medium text-gray-600 mb-3">Segment Size Distribution</p>
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={segments.map(s => ({ name: s.name, value: s.count }))}
                    cx="50%" cy="50%" outerRadius={85} dataKey="value"
                    label={({ name, percent }) => `${(percent*100).toFixed(0)}%`} labelLine={false}>
                    {segments.map((s, i) => <Cell key={i} fill={s.color || COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="card">
              <p className="text-sm font-medium text-gray-600 mb-3">Segment Characteristics</p>
              <div className="space-y-2 overflow-y-auto max-h-[220px] pr-1">
                {segments.map((s, i) => (
                  <div key={i} className="flex items-center gap-3 p-2 rounded-lg bg-gray-50">
                    <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: s.color || COLORS[i % COLORS.length] }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-semibold text-gray-800 truncate">{s.name}</p>
                      <p className="text-xs text-gray-500">
                        {s.percentage}% · Engagement {((s.characteristics?.avg_engagement||0)*100).toFixed(1)}%
                      </p>
                    </div>
                    <span className="text-xs font-bold text-gray-600">{s.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="card mt-4">
            <p className="text-sm font-medium text-gray-600 mb-3">Engagement by Segment</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={segments.map(s => ({
                name: s.name.split(' ').slice(0, 2).join(' '),
                engagement: +((s.characteristics?.avg_engagement || 0) * 100).toFixed(2),
                conversions: +(s.characteristics?.avg_conversions || 0).toFixed(1)
              }))} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis yAxisId="left"  tick={{ fontSize: 10 }} tickFormatter={v => v + '%'} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} />
                <Tooltip />
                <Legend />
                <Bar yAxisId="left"  dataKey="engagement"  name="Engagement Rate" radius={[4,4,0,0]}>
                  {segments.map((s, i) => <Cell key={i} fill={s.color || COLORS[i % COLORS.length]} />)}
                </Bar>
                <Bar yAxisId="right" dataKey="conversions" name="Avg Conversions" fill="#BDD7EE" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Empty state */}
      {!perf && !sentiment && !engagement && !forecast && segments.length === 0 && (
        <div className="card text-center py-16">
          <TrendingUp size={40} className="mx-auto text-gray-200 mb-3" />
          <p className="text-sm font-semibold text-gray-500">Select a campaign and run an analysis</p>
          <p className="text-xs text-gray-400 mt-1">Results will appear here after each analysis completes</p>
        </div>
      )}
    </div>
  )
}
