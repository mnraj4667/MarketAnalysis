import { useEffect, useState } from 'react'
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts'
import { Activity, TrendingUp, Users, DollarSign, Eye, MousePointer } from 'lucide-react'
import api from '../services/api'
import { StatCard, Spinner, SectionTitle, StatusBadge, PageHeader } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

const COLORS = ['#1F4E79','#2E75B6','#375623','#7030A0','#C55A11','#595959']

function fmt(n, type = 'number') {
  if (n == null) return '—'
  const num = parseFloat(n)
  if (isNaN(num)) return '—'
  if (type === 'currency') return '$' + num.toLocaleString('en-US', { maximumFractionDigits: 0 })
  if (type === 'percent')  return num.toFixed(2) + '%'
  if (num >= 1_000_000)    return (num / 1_000_000).toFixed(1) + 'M'
  if (num >= 1_000)        return (num / 1_000).toFixed(1) + 'K'
  return num.toLocaleString()
}

export default function DashboardPage() {
  const [summary, setSummary]     = useState(null)
  const [channels, setChannels]   = useState(null)
  const [trend, setTrend]         = useState([])
  const [loading, setLoading]     = useState(true)

  useEffect(() => {
    Promise.all([
      api.get('/dashboard/summary'),
      api.get('/dashboard/channel-comparison'),
      api.get('/dashboard/trend?metric=engagement_rate&days=30')
    ]).then(([s, c, t]) => {
      setSummary(s.data.data)
      setChannels(c.data.data)
      // Aggregate trend by date across platforms
      const byDate = {}
      t.data.data.forEach(r => {
        if (!byDate[r.date]) byDate[r.date] = { date: r.date }
        byDate[r.date][r.platform || 'all'] = parseFloat(r.value || 0)
      })
      setTrend(Object.values(byDate).slice(-30))
    }).catch(e => toast.error('Failed to load dashboard'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center h-64"><Spinner size={32} /></div>
  )

  const s  = summary || {}
  const st = s.social_totals || {}
  const et = s.event_totals  || {}
  const cs = s.campaigns     || {}
  const sent = s.sentiment   || {}
  const sentTotal = (sent.positive || 0) + (sent.negative || 0) + (sent.neutral || 0)
  const sentData = sentTotal > 0 ? [
    { name: 'Positive', value: sent.positive || 0 },
    { name: 'Neutral',  value: sent.neutral  || 0 },
    { name: 'Negative', value: sent.negative || 0 },
  ] : []

  const socialRows = channels?.social_media || []
  const channelBarData = [
    ...socialRows.map(r => ({
      name: (r.platform || '').charAt(0).toUpperCase() + (r.platform || '').slice(1),
      impressions: parseInt(r.impressions) || 0,
      conversions: parseInt(r.conversions) || 0,
    })),
    { name: 'Events', impressions: parseInt(channels?.events?.reach) || 0, conversions: parseInt(channels?.events?.conversions) || 0 },
    { name: 'Classifieds', impressions: parseInt(channels?.classifieds?.impressions) || 0, conversions: parseInt(channels?.classifieds?.responses) || 0 },
  ]

  return (
    <div>
      <PageHeader title="Executive Dashboard" subtitle={`Overview · ${new Date().toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}`} />

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Impressions" value={fmt(st.total_impressions)}
          icon={Eye} color="blue" change="+12%" changeType="up" />
        <StatCard label="Total Conversions" value={fmt((parseInt(st.total_conversions)||0)+(parseInt(et.total_conversions)||0))}
          icon={MousePointer} color="green" change="+23%" changeType="up" />
        <StatCard label="Avg Engagement" value={fmt(st.avg_engagement,'percent')}
          icon={TrendingUp} color="purple" change="+0.8%" changeType="up" />
        <StatCard label="Active Campaigns" value={fmt(cs.active)}
          icon={Activity} color="orange" change={`${cs.total} total`} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        {/* Engagement Trend */}
        <div className="card lg:col-span-2">
          <SectionTitle>Engagement Rate Trend (30 days)</SectionTitle>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d?.slice(5)} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={v => v.toFixed(1) + '%'} />
              <Tooltip formatter={(v, n) => [v?.toFixed(2) + '%', n]} />
              <Legend />
              {['facebook','instagram','twitter','linkedin'].map((p, i) => (
                <Line key={p} type="monotone" dataKey={p} stroke={COLORS[i]}
                  strokeWidth={2} dot={false} connectNulls />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Sentiment Pie */}
        <div className="card">
          <SectionTitle>Sentiment Distribution</SectionTitle>
          {sentData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={180}>
                <PieChart>
                  <Pie data={sentData} cx="50%" cy="50%" innerRadius={50} outerRadius={80}
                    dataKey="value" label={({ name, percent }) => `${name} ${(percent*100).toFixed(0)}%`}
                    labelLine={false}>
                    {sentData.map((_, i) => <Cell key={i} fill={['#375623','#94a3b8','#C55A11'][i]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 space-y-1">
                {sentData.map((s, i) => (
                  <div key={s.name} className="flex justify-between text-xs text-gray-600">
                    <span className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ background: ['#375623','#94a3b8','#C55A11'][i] }} />
                      {s.name}
                    </span>
                    <span className="font-medium">{fmt(s.value)}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="text-sm text-gray-400 text-center py-12">Run sentiment analysis to see data</p>
          )}
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        {/* Channel Comparison */}
        <div className="card">
          <SectionTitle>Channel Performance Comparison</SectionTitle>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={channelBarData} barSize={24}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={v => fmt(v)} />
              <Tooltip formatter={(v, n) => [fmt(v), n]} />
              <Legend />
              <Bar dataKey="impressions" fill="#2E75B6" name="Impressions" />
              <Bar dataKey="conversions" fill="#375623" name="Conversions" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Campaigns */}
        <div className="card">
          <SectionTitle>Recent Campaigns</SectionTitle>
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              <thead>
                <tr>
                  <th>Campaign</th>
                  <th>Channel</th>
                  <th>Status</th>
                  <th>Conversions</th>
                </tr>
              </thead>
              <tbody>
                {(s.recent_campaigns || []).length === 0 ? (
                  <tr><td colSpan={4} className="text-center text-gray-400 py-8 text-sm">No campaigns yet</td></tr>
                ) : (
                  (s.recent_campaigns || []).map(c => (
                    <tr key={c.campaign_id}>
                      <td className="font-medium max-w-[140px] truncate">{c.name}</td>
                      <td className="capitalize">{c.channel || '—'}</td>
                      <td><StatusBadge status={c.status} /></td>
                      <td>{fmt(c.conversions)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Campaign stats summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card text-center">
          <p className="text-2xl font-bold text-brand-700">{cs.total || 0}</p>
          <p className="text-xs text-gray-500 mt-1">Total Campaigns</p>
        </div>
        <div className="card text-center">
          <p className="text-2xl font-bold text-green-700">{cs.active || 0}</p>
          <p className="text-xs text-gray-500 mt-1">Active</p>
        </div>
        <div className="card text-center">
          <p className="text-2xl font-bold text-blue-700">{cs.completed || 0}</p>
          <p className="text-xs text-gray-500 mt-1">Completed</p>
        </div>
        <div className="card text-center">
          <p className="text-2xl font-bold text-orange-600">{cs.paused || 0}</p>
          <p className="text-xs text-gray-500 mt-1">Paused</p>
        </div>
      </div>
    </div>
  )
}
