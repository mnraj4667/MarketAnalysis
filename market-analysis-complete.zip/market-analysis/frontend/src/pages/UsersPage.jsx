import { useEffect, useState } from 'react'
import { UserPlus, Shield } from 'lucide-react'
import api from '../services/api'
import { PageHeader, Spinner, EmptyState, Modal, FormField } from '../components/modules/UIComponents'
import { useAuth } from '../store/AuthContext'
import toast from 'react-hot-toast'

const ROLE_COLORS = { admin:'badge-red', analyst:'badge-blue', manager:'badge-green', viewer:'badge-gray' }

export default function UsersPage() {
  const { user: me } = useAuth()
  const [users,     setUsers]     = useState([])
  const [loading,   setLoading]   = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editUser,  setEditUser]  = useState(null)
  const [saving,    setSaving]    = useState(false)
  const [regForm, setRegForm]     = useState({ email:'', password:'', fullName:'', role:'analyst' })
  const [editForm, setEditForm]   = useState({ full_name:'', role:'', is_active:true })

  async function load() {
    try {
      const { data } = await api.get('/users')
      setUsers(data.data)
    } catch { toast.error('Failed to load users') }
    finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  async function handleRegister(e) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.post('/auth/register', regForm)
      toast.success('User created')
      setShowModal(false)
      setRegForm({ email:'', password:'', fullName:'', role:'analyst' })
      load()
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create user')
    } finally { setSaving(false) }
  }

  async function handleEdit(e) {
    e.preventDefault()
    setSaving(true)
    try {
      await api.put(`/users/${editUser.user_id}`, editForm)
      toast.success('User updated')
      setEditUser(null)
      load()
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to update user')
    } finally { setSaving(false) }
  }

  async function toggleActive(u) {
    try {
      await api.put(`/users/${u.user_id}`, { is_active: !u.is_active })
      toast.success(u.is_active ? 'User deactivated' : 'User activated')
      load()
    } catch { toast.error('Failed to update user') }
  }

  function openEdit(u) {
    setEditUser(u)
    setEditForm({ full_name: u.full_name, role: u.role_name, is_active: u.is_active })
  }

  return (
    <div>
      <PageHeader title="User Management" subtitle={`${users.length} users registered`}
        actions={
          me?.role === 'admin' && (
            <button className="btn-primary" onClick={() => setShowModal(true)}>
              <UserPlus size={15} /> Add User
            </button>
          )
        } />

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size={28} /></div>
      ) : users.length === 0 ? (
        <EmptyState icon={Shield} title="No users found" />
      ) : (
        <div className="card p-0 overflow-hidden">
          <table className="table-auto w-full">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Status</th>
                <th>Last Login</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.user_id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-brand-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {u.full_name?.charAt(0).toUpperCase()}
                      </div>
                      <span className="font-medium">{u.full_name}</span>
                      {u.email === me?.email && <span className="badge-blue text-[10px] px-1.5 py-0">you</span>}
                    </div>
                  </td>
                  <td className="text-gray-500 text-xs">{u.email}</td>
                  <td>
                    <span className={`badge ${ROLE_COLORS[u.role_name] || 'badge-gray'}`}>
                      {u.role_name}
                    </span>
                  </td>
                  <td>
                    <span className={u.is_active ? 'badge-green' : 'badge-gray'}>
                      {u.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="text-xs text-gray-400">
                    {u.last_login ? new Date(u.last_login).toLocaleString() : 'Never'}
                  </td>
                  <td>
                    {me?.role === 'admin' && u.email !== me?.email && (
                      <div className="flex gap-2">
                        <button className="text-xs text-brand-700 hover:underline"
                          onClick={() => openEdit(u)}>Edit</button>
                        <button className={`text-xs hover:underline ${u.is_active ? 'text-red-500' : 'text-green-600'}`}
                          onClick={() => toggleActive(u)}>
                          {u.is_active ? 'Deactivate' : 'Activate'}
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add User Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Add New User"
        footer={<>
          <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
          <button className="btn-primary" onClick={handleRegister} disabled={saving}>
            {saving ? 'Creating…' : 'Create User'}
          </button>
        </>}>
        <div className="space-y-3">
          <FormField label="Full name *">
            <input className="input" value={regForm.fullName}
              onChange={e => setRegForm(p => ({ ...p, fullName: e.target.value }))} required />
          </FormField>
          <FormField label="Email *">
            <input type="email" className="input" value={regForm.email}
              onChange={e => setRegForm(p => ({ ...p, email: e.target.value }))} required />
          </FormField>
          <FormField label="Password *">
            <input type="password" className="input" value={regForm.password}
              onChange={e => setRegForm(p => ({ ...p, password: e.target.value }))} required minLength={8} />
          </FormField>
          <FormField label="Role">
            <select className="input" value={regForm.role}
              onChange={e => setRegForm(p => ({ ...p, role: e.target.value }))}>
              <option value="viewer">Viewer</option>
              <option value="analyst">Analyst</option>
              <option value="manager">Manager</option>
              <option value="admin">Admin</option>
            </select>
          </FormField>
        </div>
      </Modal>

      {/* Edit User Modal */}
      <Modal open={!!editUser} onClose={() => setEditUser(null)} title={`Edit – ${editUser?.full_name}`}
        footer={<>
          <button className="btn-secondary" onClick={() => setEditUser(null)}>Cancel</button>
          <button className="btn-primary" onClick={handleEdit} disabled={saving}>
            {saving ? 'Saving…' : 'Save Changes'}
          </button>
        </>}>
        <div className="space-y-3">
          <FormField label="Full name">
            <input className="input" value={editForm.full_name}
              onChange={e => setEditForm(p => ({ ...p, full_name: e.target.value }))} />
          </FormField>
          <FormField label="Role">
            <select className="input" value={editForm.role}
              onChange={e => setEditForm(p => ({ ...p, role: e.target.value }))}>
              <option value="viewer">Viewer</option>
              <option value="analyst">Analyst</option>
              <option value="manager">Manager</option>
              <option value="admin">Admin</option>
            </select>
          </FormField>
          <FormField label="Status">
            <select className="input" value={String(editForm.is_active)}
              onChange={e => setEditForm(p => ({ ...p, is_active: e.target.value === 'true' }))}>
              <option value="true">Active</option>
              <option value="false">Inactive</option>
            </select>
          </FormField>
        </div>
      </Modal>
    </div>
  )
}
