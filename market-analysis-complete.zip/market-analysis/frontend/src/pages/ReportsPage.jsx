import { useEffect, useState } from 'react'
import { FileText, Plus, Download, Eye } from 'lucide-react'
import api from '../services/api'
import { PageHeader, Modal, FormField, Spinner, EmptyState, StatusBadge } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

export default function ReportsPage() {
  const [reports,   setReports]   = useState([])
  const [campaigns, setCampaigns] = useState([])
  const [loading,   setLoading]   = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [saving,    setSaving]    = useState(false)
  const [preview,   setPreview]   = useState(null)
  const [form, setForm] = useState({
    title: '', report_type: 'campaign_summary',
    campaign_id: '', format: 'json'
  })

  useEffect(() => {
    Promise.all([
      api.get('/reports'),
      api.get('/campaigns?limit=100')
    ]).then(([r, c]) => {
      setReports(r.data.data)
      setCampaigns(c.data.data)
    }).catch(() => toast.error('Failed to load reports'))
    .finally(() => setLoading(false))
  }, [])

  async function handleGenerate(e) {
    e.preventDefault()
    setSaving(true)
    try {
      const { data } = await api.post('/reports/generate', form)
      setReports(p => [data.data.report, ...p])
      setPreview(data.data)
      setShowModal(false)
      toast.success('Report generated')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to generate report')
    } finally { setSaving(false) }
  }

  function downloadJson(content, title) {
    const blob = new Blob([JSON.stringify(content, null, 2)], { type: 'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `${title.replace(/\s+/g, '_')}_${Date.now()}.json`
    a.click()
  }

  return (
    <div>
      <PageHeader title="Reports" subtitle="Generate and download analytical reports"
        actions={
          <button className="btn-primary" onClick={() => setShowModal(true)}>
            <Plus size={15} /> Generate Report
          </button>
        } />

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size={28} /></div>
      ) : reports.length === 0 ? (
        <EmptyState icon={FileText} title="No reports yet"
          description="Generate your first analytical report"
          action={
            <button className="btn-primary" onClick={() => setShowModal(true)}>
              <Plus size={15} /> Generate Report
            </button>
          } />
      ) : (
        <div className="card p-0 overflow-hidden mb-6">
          <table className="table-auto w-full">
            <thead>
              <tr>
                <th>Title</th>
                <th>Type</th>
                <th>Format</th>
                <th>Status</th>
                <th>Created by</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {reports.map(r => (
                <tr key={r.report_id}>
                  <td className="font-medium text-gray-800 max-w-[200px] truncate">{r.title}</td>
                  <td className="capitalize text-xs">{r.report_type?.replace(/_/g, ' ')}</td>
                  <td className="uppercase text-xs font-mono">{r.format}</td>
                  <td><StatusBadge status={r.status} /></td>
                  <td className="text-xs text-gray-500">{r.created_by_name || '—'}</td>
                  <td className="text-xs text-gray-400">{new Date(r.created_at).toLocaleDateString()}</td>
                  <td>
                    <div className="flex gap-1">
                      <button className="text-brand-700 hover:text-brand-500 p-1"
                        title="Preview"
                        onClick={() => api.get(`/reports/${r.report_id}`).then(res => setPreview({ report: res.data.data }))}>
                        <Eye size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Report Preview */}
      {preview && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800">{preview.report?.title || 'Report Preview'}</h3>
            <div className="flex gap-2">
              {preview.content && (
                <button className="btn-secondary text-xs"
                  onClick={() => downloadJson(preview.content, preview.report?.title || 'report')}>
                  <Download size={13} /> Download JSON
                </button>
              )}
              <button className="btn-secondary text-xs" onClick={() => setPreview(null)}>Close</button>
            </div>
          </div>
          {preview.content ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 font-medium mb-2 uppercase">Campaign</p>
                {preview.content.campaign ? (
                  <>
                    <p className="font-semibold">{preview.content.campaign.name}</p>
                    <p className="text-xs text-gray-500 capitalize mt-0.5">{preview.content.campaign.channel?.replace('_',' ')} · {preview.content.campaign.status}</p>
                    <p className="text-xs text-gray-500">Budget: {preview.content.campaign.budget ? '$'+parseFloat(preview.content.campaign.budget).toLocaleString() : '—'}</p>
                  </>
                ) : <p className="text-gray-400 text-xs">No campaign data</p>}
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 font-medium mb-2 uppercase">Social Media</p>
                {(preview.content.social || []).length > 0 ? (
                  preview.content.social.map(s => (
                    <div key={s.platform} className="mb-1">
                      <p className="text-xs font-medium capitalize">{s.platform}</p>
                      <p className="text-xs text-gray-500">Impressions: {parseInt(s.impressions || 0).toLocaleString()} · Conv: {s.conversions || 0}</p>
                    </div>
                  ))
                ) : <p className="text-gray-400 text-xs">No social data</p>}
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 font-medium mb-2 uppercase">Sentiment</p>
                {(preview.content.sentiment || []).length > 0 ? (
                  preview.content.sentiment.map(s => (
                    <div key={s.sentiment_class} className="flex justify-between text-xs mb-1">
                      <span className="capitalize">{s.sentiment_class}</span>
                      <span className="font-medium">{s.count}</span>
                    </div>
                  ))
                ) : <p className="text-gray-400 text-xs">No sentiment data</p>}
              </div>
              <div className="md:col-span-3 bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500 font-medium mb-2 uppercase">Raw JSON Preview</p>
                <pre className="text-xs text-gray-600 overflow-x-auto max-h-48">
                  {JSON.stringify(preview.content, null, 2)}
                </pre>
              </div>
            </div>
          ) : (
            <pre className="text-xs text-gray-600 overflow-x-auto">
              {JSON.stringify(preview.report, null, 2)}
            </pre>
          )}
        </div>
      )}

      {/* Generate Modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Generate Report"
        footer={<>
          <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
          <button className="btn-primary" onClick={handleGenerate} disabled={saving}>
            {saving ? 'Generating…' : 'Generate'}
          </button>
        </>}>
        <div className="space-y-4">
          <FormField label="Report title *">
            <input className="input" value={form.title}
              onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
              placeholder="e.g. Q1 2025 Campaign Summary" required />
          </FormField>
          <FormField label="Report type">
            <select className="input" value={form.report_type}
              onChange={e => setForm(p => ({ ...p, report_type: e.target.value }))}>
              <option value="campaign_summary">Campaign Summary</option>
              <option value="channel_comparison">Channel Comparison</option>
              <option value="sentiment_report">Sentiment Report</option>
              <option value="roi_analysis">ROI Analysis</option>
              <option value="executive_overview">Executive Overview</option>
            </select>
          </FormField>
          <FormField label="Campaign (optional)">
            <select className="input" value={form.campaign_id}
              onChange={e => setForm(p => ({ ...p, campaign_id: e.target.value }))}>
              <option value="">— All campaigns —</option>
              {campaigns.map(c => (
                <option key={c.campaign_id} value={c.campaign_id}>{c.name}</option>
              ))}
            </select>
          </FormField>
          <FormField label="Format">
            <select className="input" value={form.format}
              onChange={e => setForm(p => ({ ...p, format: e.target.value }))}>
              <option value="json">JSON</option>
              <option value="csv">CSV</option>
              <option value="pdf">PDF</option>
              <option value="excel">Excel</option>
            </select>
          </FormField>
        </div>
      </Modal>
    </div>
  )
}
