import { useState } from 'react'
import { User, Lock, Info } from 'lucide-react'
import api from '../services/api'
import { useAuth } from '../store/AuthContext'
import { PageHeader, FormField } from '../components/modules/UIComponents'
import toast from 'react-hot-toast'

export default function SettingsPage() {
  const { user } = useAuth()
  const [tab, setTab] = useState(0)
  const [pwForm, setPwForm] = useState({ current_password:'', new_password:'', confirm:'' })
  const [saving, setSaving] = useState(false)

  async function handlePassword(e) {
    e.preventDefault()
    if (pwForm.new_password !== pwForm.confirm)
      return toast.error('Passwords do not match')
    if (pwForm.new_password.length < 8)
      return toast.error('Password must be at least 8 characters')
    setSaving(true)
    try {
      await api.post('/users/password', {
        current_password: pwForm.current_password,
        new_password:     pwForm.new_password
      })
      toast.success('Password changed successfully')
      setPwForm({ current_password:'', new_password:'', confirm:'' })
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to change password')
    } finally { setSaving(false) }
  }

  const TABS = ['Profile', 'Security', 'System Info']

  return (
    <div className="max-w-2xl">
      <PageHeader title="Settings" />

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-lg p-1 mb-6 w-fit">
        {TABS.map((t, i) => (
          <button key={i} onClick={() => setTab(i)}
            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors
              ${tab === i ? 'bg-white text-brand-700 shadow-sm' : 'text-gray-600 hover:text-gray-800'}`}>
            {t}
          </button>
        ))}
      </div>

      {/* Profile */}
      {tab === 0 && (
        <div className="card">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-brand-700 flex items-center justify-center text-white text-2xl font-bold">
              {user?.fullName?.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 text-lg">{user?.fullName}</h3>
              <p className="text-sm text-gray-500">{user?.email}</p>
              <span className="badge-blue mt-1 inline-block capitalize">{user?.role}</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
            {[
              ['Role', user?.role],
              ['Email', user?.email],
              ['Permissions', (user?.permissions || []).includes('*') ? 'Full access' : (user?.permissions || []).slice(0,3).join(', ')],
            ].map(([k, v]) => (
              <div key={k}>
                <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-1">{k}</p>
                <p className="text-sm font-medium text-gray-800 capitalize">{v}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Security */}
      {tab === 1 && (
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">Change Password</h3>
          <form onSubmit={handlePassword} className="space-y-4">
            <FormField label="Current password">
              <input type="password" className="input" value={pwForm.current_password}
                onChange={e => setPwForm(p => ({ ...p, current_password: e.target.value }))} required />
            </FormField>
            <FormField label="New password" hint="Minimum 8 characters">
              <input type="password" className="input" value={pwForm.new_password}
                onChange={e => setPwForm(p => ({ ...p, new_password: e.target.value }))} required minLength={8} />
            </FormField>
            <FormField label="Confirm new password">
              <input type="password" className="input" value={pwForm.confirm}
                onChange={e => setPwForm(p => ({ ...p, confirm: e.target.value }))} required />
            </FormField>
            <button type="submit" className="btn-primary" disabled={saving}>
              {saving ? 'Saving…' : 'Update Password'}
            </button>
          </form>
        </div>
      )}

      {/* System Info */}
      {tab === 2 && (
        <div className="card">
          <h3 className="font-semibold text-gray-800 mb-4">System Information</h3>
          <div className="space-y-3">
            {[
              ['Application', 'AI-Enabled Market Analysis System'],
              ['Version', '1.0.0'],
              ['Backend', 'Node.js 20 + Express.js'],
              ['AI Service', 'Python 3.11 + FastAPI'],
              ['Database', 'PostgreSQL 15 + MongoDB 6'],
              ['Cache', 'Redis 7'],
              ['Frontend', 'React 18 + Vite + Tailwind CSS'],
              ['API Docs', '/api-docs (Swagger UI)'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between py-2 border-b border-gray-50 text-sm">
                <span className="text-gray-500">{k}</span>
                <span className="font-medium text-gray-800">{v}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 p-3 bg-blue-50 rounded-lg text-xs text-blue-700">
            <p className="font-semibold mb-1">Default Login</p>
            <p>Admin: admin@marketai.com / Admin@2024</p>
            <p>Analyst: analyst@marketai.com / Admin@2024</p>
          </div>
        </div>
      )}
    </div>
  )
}
