/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50:  '#EBF3FB',
          100: '#BDD7EE',
          500: '#2E75B6',
          700: '#1F4E79',
          900: '#0D2B45',
        }
      }
    }
  },
  plugins: []
}
